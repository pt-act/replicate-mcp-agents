# MASTER_CONTEXT.md — replicate-mcp-agents

**Project:** replicate-mcp-agents  
**Version:** 0.8.0  
**Language:** Python 3.10+  
**Framework:** MCP-native agent orchestration for Replicate AI models  
**Last Updated:** 2026-04-30

---

## Project Identity

A Python framework for orchestrating AI agents using Replicate's model hosting platform, implemented as a native Model Context Protocol (MCP) server. Enables declarative agent definition, intelligent routing, distributed execution, and production-grade observability.

---

## Core Architecture

### Module Hierarchy

```
src/replicate_mcp/
├── __init__.py              # Public API exports
├── sdk.py                   # @agent decorator, AgentBuilder, WorkflowBuilder
├── server.py                # MCP server entrypoints (stdio, HTTP, SSE)
├── agents/
│   ├── execution.py         # AgentExecutor (concurrency, circuit breaker, retry)
│   ├── registry.py          # AgentRegistry, AgentMetadata
│   ├── composition.py       # WorkflowComposer (DAG execution)
│   └── transforms.py        # Safe transform registry (no eval)
├── routing.py               # CostAwareRouter, Thompson Sampling, UCB1
├── qos.py                   # QoS tiers, QoSPolicy, AdaptiveRouter
├── discovery.py             # ModelDiscovery with version pinning
├── distributed.py           # DistributedExecutor, HttpWorkerTransport
├── worker_server.py         # HTTP worker node hosting
├── worker_circuit_breaker.py # Worker-level circuit breaker (v0.8.0)
├── resilience.py            # CircuitBreaker, RetryConfig
├── cache.py                 # ResultCache with eviction policies (v0.8.0)
├── ratelimit.py             # TokenBucket rate limiting
├── observability.py         # OpenTelemetry integration
├── latitude.py              # Latitude.sh observability integration
├── validation.py            # Pydantic schemas
├── exceptions.py            # Error hierarchy
├── interfaces.py            # Protocol contracts
├── security.py              # Secret management, eval pattern detection
├── dsl.py                   # Safe AST-based expression evaluator
└── cli/                     # Click-based CLI commands
```

### Key Design Patterns

1. **Registry Pattern:** `AgentRegistry`, `PluginRegistry`, `TransformRegistry`
2. **Builder Pattern:** `AgentBuilder`, `WorkflowBuilder`
3. **Strategy Pattern:** Routers (`CostAwareRouter`, `UCB1Router`, `AdaptiveRouter`)
4. **Circuit Breaker:** `CircuitBreaker` → `WorkerCircuitBreaker` (extension)
5. **Plugin System:** `BasePlugin` with lifecycle hooks

---

## Version History

| Version | Date | Key Features |
|---------|------|--------------|
| 0.6.0 | 2026-04-20 | Router persistence, mutable plugins, YAML workflows |
| 0.7.0 | 2026-04-27 | Technical debt remediation, lazy initialization, multi-objective Thompson |
| **0.8.0** | **2026-04-30** | **Worker Circuit Breakers, Model Version Pinning, Cache Eviction Policy** |

---

## v0.8.0 Features (Current)

### Feature #9: Worker Circuit Breakers
- **Purpose:** Distributed worker reliability tracking
- **Files:** `worker_circuit_breaker.py`, `distributed.py`, `worker_server.py`
- **Key Classes:** `WorkerCircuitBreaker`, `WorkerCircuitState`, `WorkerCircuitOpenError`
- **Tests:** 31 unit + integration tests

### Feature #18: Model Version Pinning
- **Purpose:** Reproducible inference with pinned model versions
- **Files:** `discovery.py`
- **Key Classes:** `VersionPinningMode` (LATEST, EXACT, MINOR)
- **Tests:** 27 unit tests

### Feature #25: Cache Eviction Policy
- **Purpose:** Configurable cache eviction strategies
- **Files:** `cache.py`
- **Key Classes:** `EvictionPolicy` (LRU, TTL, FIFO, LFU)
- **Tests:** 30 unit tests

---

## Security Status

**Audit Date:** 2026-04-30  
**Auditor:** Validator/Fixer Framework V3  
**Finding:** 11 alleged `eval()`/`exec()` vulnerabilities  
**Verification:** **ALL FALSE POSITIVES**  

### Root Cause
Naive string matching flagged:
- Docstring references to eval
- Safe AST-based `evaluate()` method
- Regex patterns to detect eval
- Function names containing "eval"

### Verification
```bash
grep -rP "(?<!\w)eval\s*\(" src/   # 0 matches
grep -rP "(?<!\w)exec\s*\(" src/   # 0 matches
```

**Status:** ✅ **SECURE — No vulnerabilities**

---

## Test Coverage

- **Total Tests:** 1150
- **Unit Tests:** 1133
- **Integration Tests:** 17
- **Coverage:** >90% (enforced by CI)
- **All Tests:** ✅ Passing

---

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| replicate | >=2.0.0b1,<3.0.0 | Replicate API SDK |
| mcp | >=1.20.0,<2.0.0 | Model Context Protocol |
| click | >=8.1.7,<9.0.0 | CLI framework |
| pydantic | >=2.9.0,<3.0.0 | Schema validation |
| anyio | >=4.6.0,<5.0.0 | Async concurrency |
| httpx | >=0.27.0,<0.28.0 | HTTP client |
| opentelemetry-sdk | >=1.26.0,<2.0.0 | Observability (optional) |

---

## Entry Points

**CLI:**
- `replicate-agent serve` — MCP server
- `replicate-agent agents run` — Execute single agent
- `replicate-agent workflows run` — Execute workflow
- `replicate-agent workers start` — Launch HTTP worker
- `replicate-agent doctor` — Health checks

**Programmatic:**
```python
from replicate_mcp import (
    agent, AgentBuilder, WorkflowBuilder,
    DiscoveryConfig, ModelDiscovery, VersionPinningMode,
    ResultCache, EvictionPolicy,
    DistributedExecutor, WorkerCircuitBreaker,
    CostAwareRouter, QoSPolicy,
)
```

---

## Current Focus

1. ✅ v0.8.0 features complete (Worker CBs, Version Pinning, Cache Eviction)
2. ✅ Security audit verified (false positives documented)
3. ✅ All 1150 tests passing
4. ✅ Ruff/mypy compliance verified
5. 🔄 Next: v0.9.0 planning

---

## Documentation Index

| Document | Purpose |
|----------|---------|
| `docs/adr/010-worker-circuit-breakers.md` | ADR-010: Worker Circuit Breakers |
| `docs/adr/011-version-pinning.md` | ADR-011: Model Version Pinning |
| `docs/adr/012-cache-eviction-policy.md` | ADR-012: Cache Eviction Policy |
| `docs/AUDIT/AUDIT_SUMMARY.md` | Security audit summary |
| `docs/AUDIT/FALSE_POSITIVE_ANALYSIS.md` | False positive breakdown |
| `docs/AUDIT/SECURITY_AUDIT_REPORT.md` | Original audit report |
| `CHANGELOG.md` | Full version history |
| `README.md` | Project overview |

---

**[Quantum_State: ACTIVE]**  
**[Last_Sync: 2026-04-30]**
