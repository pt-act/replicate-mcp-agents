# Architectural Decisions — replicate-mcp-agents

**Framework:** Orion-OS v2.4  
**Updated:** 2026-04-30  
**Status:** v0.8.0 Complete

---

## ADR-010: Worker Circuit Breakers (Accepted 2026-04-29)

**Context:** Distributed workers can fail independently, causing cascading failures if coordinators continue routing to unhealthy nodes.

**Decision:** Implement worker-level circuit breakers with self-tracking, health endpoint exposure, and coordinator-side routing decisions.

**Consequences:**
- (+) Automatic failover for failing workers
- (+) Gradual recovery with HALF_OPEN state
- (+) Observable circuit state via health endpoints
- (-) Additional latency for circuit state checks
- (-) Cached state may be stale

**Status:** ✅ Implemented, tested, documented

---

## ADR-011: Model Version Pinning (Accepted 2026-04-29)

**Context:** Production deployments require reproducible inference. Model updates on Replicate can silently change agent behavior.

**Decision:** Add version pinning modes (LATEST, EXACT, MINOR) to DiscoveryConfig with pinned_versions dictionary.

**Consequences:**
- (+) Deterministic model versions for compliance
- (+) Controlled, explicit updates
- (+) Mixed pinning (some pinned, some latest)
- (-) Pinned versions may become unavailable
- (-) Security patches don't auto-apply

**Status:** ✅ Implemented, tested, documented

---

## ADR-012: Cache Eviction Policy (Accepted 2026-04-29)

**Context:** Different workloads have different cache access patterns. LRU is not optimal for all scenarios.

**Decision:** Support configurable eviction policies (LRU, TTL, FIFO, LFU) with background eviction and thread safety.

**Consequences:**
- (+) Workload-optimized caching
- (+) Thread-safe for multi-worker deployments
- (+) Background eviction prevents memory leaks
- (-) +24 bytes per entry for metadata
- (-) Lock contention (minimal, ~1-5μs)

**Status:** ✅ Implemented, tested, documented

---

## ADR-009: Latitude Integration (Accepted 2026-04-27)

**Context:** Need observability and telemetry for production deployments.

**Decision:** Integrate with Latitude.sh for prompt management, tracing, and evaluation.

**Consequences:**
- (+) Zero-overhead when API key absent
- (+) Automatic tracing via plugin
- (+) Graceful degradation on errors
- (-) Additional optional dependency

**Status:** ✅ Implemented, tested

---

## ADR-008: Lazy Initialization (Accepted 2026-04-27)

**Context:** Module-level mutable state at import time prevents parallel test execution and multi-tenant support.

**Decision:** Use lazy initialization with `_ensure_*()` factory functions for registries.

**Consequences:**
- (+) Enables parallel test execution
- (+) Supports multi-tenant deployments
- (+) No side effects at import time
- (-) Slightly more complex initialization code

**Status:** ✅ Implemented, tested

---

## ADR-007: Multi-Objective Thompson Sampling (Accepted 2026-04-27)

**Context:** Beta posterior conflates multiple objectives (cost, latency, quality) into binary success/failure.

**Decision:** Implement Gaussian Thompson Sampling on scalarized utility scores.

**Consequences:**
- (+) Proper multi-objective optimization
- (+) Separates concerns: QoS filters objectives, Thompson optimizes
- (+) Tracks utility distribution parameters
- (-) More complex than Beta-based approach

**Status:** ✅ Implemented, tested

---

## ADR-006: Model Discovery (Accepted 2026-04-20)

**Context:** Static model catalogs require manual updates when Replicate adds models.

**Decision:** Auto-discover models from Replicate API with TTL-based caching and background refresh.

**Consequences:**
- (+) Always up-to-date model catalog
- (+) Configurable filtering (owner, tags)
- (+) Non-blocking on cache hit
- (-) Requires API token for discovery
- (-) Cache miss adds latency

**Status:** ✅ Implemented, tested, extended with version pinning

---

## ADR-005: Cost-Aware Routing (Accepted 2026-04-20)

**Context:** Different models have different cost/latency/quality tradeoffs. Static routing wastes budget.

**Decision:** Implement EMA-based tracking with Thompson Sampling for exploration/exploitation.

**Consequences:**
- (+) Automatic model selection optimization
- (+) Balances cost, latency, quality
- (+) Configurable weights per use case
- (-) Requires warm-up period
- (-) Exploration costs budget

**Status:** ✅ Implemented, tested, extended with multi-objective

---

## ADR-004: Circuit Breaker Pattern (Accepted 2026-04-15)

**Context:** Replicate API can fail; cascading failures must be prevented.

**Decision:** Implement circuit breaker with CLOSED/OPEN/HALF_OPEN states and automatic recovery.

**Consequences:**
- (+) Prevents cascading failures
- (+) Automatic recovery
- (+) Configurable thresholds
- (-) Adds complexity to error handling

**Status:** ✅ Implemented, extended for workers

---

## ADR-003: MCP Protocol Native (Accepted 2026-04-10)

**Context:** Need standardized protocol for agent communication.

**Decision:** Implement native MCP (Model Context Protocol) server instead of custom API.

**Consequences:**
- (+) Ecosystem compatibility
- (+) Standardized tool/resource patterns
- (+) Multiple transport options (stdio, HTTP, SSE)
- (-) Protocol complexity
- (-) Dependency on MCP SDK

**Status:** ✅ Implemented, tested

---

## ADR-002: Async-First Design (Accepted 2026-04-05)

**Context:** Agent orchestration is I/O-bound (API calls, streaming).

**Decision:** Use async/await throughout with anyio for cross-platform compatibility.

**Consequences:**
- (+) Efficient I/O handling
- (+) Concurrent agent execution
- (+) Streaming support
- (-) Steeper learning curve for contributors
- (-) Debugging complexity

**Status:** ✅ Implemented, pervasive

---

## ADR-001: Registry Pattern for Agents (Accepted 2026-04-01)

**Context:** Agents need to be discovered, registered, and executed dynamically.

**Decision:** Use registry pattern with `AgentRegistry` for metadata and `AgentExecutor` for invocation.

**Consequences:**
- (+) Decoupled registration from execution
- (+) Runtime agent discovery
- (+) Metadata-driven behavior
- (-) Global state (mitigated by lazy initialization)

**Status:** ✅ Implemented, core pattern

---

## Decision Log

| ADR | Date | Decision | Status |
|-----|------|----------|--------|
| 001 | 2026-04-01 | Registry pattern | ✅ Implemented |
| 002 | 2026-04-05 | Async-first | ✅ Implemented |
| 003 | 2026-04-10 | MCP native | ✅ Implemented |
| 004 | 2026-04-15 | Circuit breaker | ✅ Implemented |
| 005 | 2026-04-20 | Cost-aware routing | ✅ Implemented |
| 006 | 2026-04-20 | Model discovery | ✅ Implemented |
| 007 | 2026-04-27 | Multi-objective Thompson | ✅ Implemented |
| 008 | 2026-04-27 | Lazy initialization | ✅ Implemented |
| 009 | 2026-04-27 | Latitude integration | ✅ Implemented |
| 010 | 2026-04-29 | Worker circuit breakers | ✅ Implemented |
| 011 | 2026-04-29 | Model version pinning | ✅ Implemented |
| 012 | 2026-04-29 | Cache eviction policy | ✅ Implemented |

---

**[Quantum_State: RECORDED]**
