---
name: Validator/Fixer Framework
description: Bidirectional validation system with persistent learning, PM-Auditor integration, and multi-model onboarding
version: 2.0.0
author: Orion-OS
tags: [validation, security, code-quality, mcp, bidirectional-learning, pm-auditor, benchmarks]
mcp_server: validator-fixer
---

## Purpose

The **Validator/Fixer MCP** is a bidirectional validation system where a validator model reviews code and the coder model can push back on false positives. Both models learn from every interaction, with persistent memory across sessions.

It is **not** a code reviewer. It is a **two-model coordination framework** that:

- Validates generated code against specs and security patterns
- Lets the coder assess, accept, or challenge validator feedback
- Persists learning across sessions so both models improve over time
- Exports evidence bundles for PM-Auditor arbitration when disagreements arise
- Supports multiple model onboarding for benchmarks and comparative analysis

### Why Use This MCP

| Without Validator MCP | With Validator MCP |
|----------------------|-------------------|
| One model reviews itself (echo chamber) | Different model provides external perspective |
| Same mistakes repeated across sessions | Persistent learning accumulates knowledge |
| Disagreements resolved by guessing | Confidence-based resolution with human escalation |
| No evidence for PM-Auditor | Structured evidence bundles export automatically |
| Single model benchmarking | Multi-model onboarding for comparative analysis |

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    MCP Server                            │
│                                                          │
│  Validation Tools        Learning Tools    PM-Auditor   │
│  ────────────────        ──────────────    ──────────   │
│  validate_code           validate_with     export_      │
│  validate_syntax         _learning         evidence_    │
│  validate_security       get_learning      bundle       │
│  validate_types          _history                       │
│  validate_contract                                      │
│  suggest_fix                                            │
│  validate_and_fix                                       │
│                                                          │
└──────────────┬──────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│              SharedMemory (.validator-memory/)            │
│                                                            │
│  learning-notes.json    — patterns learned from errors    │
│  pushback-history.json  — coder challenges + outcomes     │
│  resolutions.json       — who was correct, what happened  │
│  sessions/              — per-session snapshots           │
└──────────────┬───────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│          BidirectionalValidator                            │
│                                                            │
│  ValidationRetryLoop                                      │
│  ├── validate → diagnose → fix → retry                    │
│  ├── coder validates feedback (bidirectional)             │
│  ├── resolve_disagreement() with PM-Auditor mapping       │
│  └── persist learning after each iteration                │
│                                                            │
│  Resolution → PM-Auditor Verdict Mapping:                 │
│  TRUST_VALIDATOR   → REQUEST-CHANGES                      │
│  TRUST_CODER       → APPROVE                              │
│  ESCALATE_TO_JUDGE → PM-Auditor full audit                │
│  HUMAN_REVIEW      → Interactive pause + present          │
│  TRACK_AND_LEARN   → Log both sides, continue             │
└──────────────────────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│            Evidence Export → PM-Auditor                   │
│                                                            │
│  export_evidence_bundle() generates:                      │
│  ├── validation_results.json                              │
│  ├── disagreement_history.json                            │
│  ├── learning_summary.json                                │
│  └── pm-auditor-ready.json (matches PM-Auditor template)  │
└──────────────────────────────────────────────────────────┘
```

---

## MCP Server Configuration

**Status**: Configured and operational

**Registration** (`mcp.validator-fixer.json`):
```json
{
  "mcpServers": {
    "validator-fixer": {
      "command": "python",
      "args": [
        "/Users/rna/Downloads/Validator_Fixer-Framework.V3-main/server.py"
      ],
      "env": {},
      "disabled": false
    }
  }
}
```

**Server Location**: `/Users/rna/Downloads/Validator_Fixer-Framework.V3-main/`

---

## Available Tools

### Validation Tools

| Tool | What It Does | When to Use |
|------|-------------|-------------|
| `validate_code` | Full pipeline: syntax → types → security → contract | **Default** after implementing any spec |
| `validate_syntax` | Syntax-only (fast, deterministic) | Quick sanity check before committing |
| `validate_security` | Security scan (SQL injection, XSS, secrets) | After DB queries, auth code, API handlers |
| `validate_types` | Type-hint completeness on public functions | Before finalizing Python module API |
| `validate_contract` | API endpoints vs OpenAPI spec | After generating FastAPI/Express routes |
| `suggest_fix` | Pattern-based fix for a known error code | When validation returns fixable errors |
| `validate_and_fix` | Full retry loop: validate → diagnose → fix → re-validate | Automatic iterative repair |

### Learning Tools

| Tool | What It Does | When to Use |
|------|-------------|-------------|
| `validate_with_learning` | Validation with persistent memory | After spec completion — learns from results |
| `get_learning_history` | Retrieve accumulated learning data | Periodically to see what both models learned |
| `export_evidence_bundle` | Generate PM-Auditor compatible evidence | Before invoking PM-Auditor for arbitration |

---

## Tool Signatures

### `validate_with_learning` — Validation with Persistent Memory

```
Parameters:
  code: str              — source code to validate
  language: str          — "python" | "javascript" | "typescript" | "sql"
  spec: str?             — optional JSON with API spec
  coder_model_id: str?   — identifier for the coding model (for multi-model tracking)
  session_id: str?       — identifier for this validation session

Returns:
  {
    "valid": true|false,
    "confidence": 0.0-1.0,
    "errors": [...],
    "warnings": [...],
    "learning_applied": [
      {"pattern": "...", "source": "previous_session", "prevented": true}
    ],
    "session_id": "..."
  }
```

### `get_learning_history` — Retrieve Accumulated Knowledge

```
Parameters:
  model_id: str?         — filter by specific model (all models if omitted)
  category: str?         — filter: "errors" | "pushbacks" | "resolutions" | "all"
  limit: int?            — max entries to return (default: 100)

Returns:
  {
    "total_sessions": 45,
    "models_tracked": ["gpt-4", "claude-sonnet", "gemini-pro"],
    "learning_notes": [...],
    "pushback_history": [...],
    "resolution_outcomes": [...],
    "accuracy_trends": {
      "coder_pushback_success_rate": 0.78,
      "validator_false_positive_rate": 0.12,
      "improvement_over_time": "+15%"
    }
  }
```

### `export_evidence_bundle` — PM-Auditor Compatible Evidence

```
Parameters:
  session_id: str?       — specific session (latest if omitted)
  include_learning: bool — include learning history (default: true)

Returns:
  {
    "validation_results": {...},
    "disagreement_history": [...],
    "learning_summary": {...},
    "pm_auditor_ready": {
      "coder_summary": "...",           // matches PM-Auditor coder-summary template
      "evidence_artifacts": [...],       // validation logs, test results
      "quality_gates": {                 // 7-dimension assessment
        "functional_correctness": true,
        "determinism": true,
        "observability": true,
        "security": true,
        "documentation": true,
        "regression_protection": true,
        "property_validation": false
      },
      "recommended_verdict": "APPROVE-WITH-CONDITIONS"
    }
  }
```

---

## Tool Signatures (Existing)

### `validate_code` — Full Pipeline

```
Parameters:
  code: str              — source code to validate
  language: str          — "python" | "javascript" | "typescript" | "sql" (default: "python")
  config_path: str?      — optional path to validator.yaml override
  spec: str?             — optional JSON with API spec / type spec
```

### `validate_security` — Security Scan

```
Parameters:
  code: str              — source code to scan
```

### `validate_contract` — API Contract Check

```
Parameters:
  code: str              — generated API code
  spec: str              — JSON with "endpoints" dict mapping paths → HTTP methods
```

### `suggest_fix` — Get a Fix Pattern

```
Parameters:
  code: str              — the code with the issue
  error_code: str        — error code from validation (e.g. "SQL_INJECTION", "SECRETS")
```

### `validate_and_fix` — Iterative Retry Loop

```
Parameters:
  code: str              — source code
  language: str          — default "python"
  max_iterations: int    — retry rounds (default 3)
  config_path: str?      — optional config override
  spec: str?             — optional JSON spec
```

---

## Available Resources

| URI | Returns |
|-----|---------|
| `validator://config` | Current `validator.yaml` contents |
| `validator://security-patterns` | Full security regex pattern database as JSON |
| `validator://learning-history` | Persistent learning data as JSON |

---

## Available Prompts

| Prompt | Parameters | Use Case |
|--------|-----------|----------|
| `Validate After Spec` | `file_path`, `language` | Standard post-implementation validation |
| `Security Audit` | `file_path` | Deep security scan with fix suggestions |
| `PM-Auditor Export` | `session_id` | Generate evidence bundle for PM-Auditor |
| `Learning Review` | `model_id` | Review what a specific model has learned |

---

## Workflows

### 1. Standard Post-Spec Validation (Primary Use Case)

```
1. Coder model completes spec implementation
2. Call validate_with_learning (not validate_code)
   - Coder model ID recorded for multi-model tracking
   - Prior learning applied automatically
3. If errors found:
   a. Coder assesses each error (real or false positive?)
   b. For real errors: apply fix, re-validate
   c. For false positives: push back with reasoning
4. Disagreement resolution:
   - TRUST_VALIDATOR → fix the code
   - TRUST_CODER → validator learns from pushback
   - HUMAN_REVIEW → pause, present both sides, wait
   - ESCALATE_TO_JUDGE → export evidence, invoke PM-Auditor
5. Learning persisted to .validator-memory/
```

### 2. PM-Auditor Arbitration Flow

```
1. Disagreement triggers ESCALATE_TO_JUDGE or HUMAN_REVIEW
2. Call export_evidence_bundle(session_id)
3. Coder posts summary using PM-Auditor coder-summary template
4. Human invokes PM-Auditor skill with evidence bundle
5. PM-Auditor evaluates against 7 quality gates
6. PM-Auditor issues verdict:
   - APPROVE: coder was right, validator adjusts
   - APPROVE-WITH-CONDITIONS: minor gaps, proceed with notes
   - REQUEST-CHANGES: validator was right, coder must fix
   - BLOCKED: critical issues, must resolve before proceeding
7. Resolution recorded in shared memory for both models
```

### 3. Multi-Model Onboarding (Benchmarks)

```
1. Register models with unique IDs:
   - model_id: "gpt-4-turbo", "claude-sonnet-4", "gemini-2.5-pro"
2. Each model runs validate_with_learning with its model_id
3. Learning tracked per-model in .validator-memory/
4. Call get_learning_history(model_id=X) to compare:
   - Which model catches more real issues?
   - Which model has higher false positive rate?
   - Which model's pushbacks are more accurate?
5. Use for:
   - Model selection for different task types
   - Benchmark reports
   - Calibration of confidence scores per model
```

### 4. Security-First Flow

```
1. Call validate_security (deterministic, fast)
2. For each finding: call suggest_fix with error_code
3. Apply fixes, re-validate until clean
4. Then call validate_with_learning for full pipeline
5. If security issues persist after fix attempts:
   - export_evidence_bundle for PM-Auditor security audit
```

---

## Disagreement Resolution Matrix

```
                    VALIDATOR CONFIDENCE
                 LOW         MEDIUM        HIGH
           ┌─────────────┬─────────────┬─────────────┐
     LOW   │   HUMAN     │   TRUST     │   TRUST     │
 CODER     │   REVIEW    │   VALIDATOR │   VALIDATOR │
 CONFIDENCE├─────────────┼─────────────┼─────────────┤
  MEDIUM   │   TRUST     │   TRACK     │   TRUST     │
           │   CODER     │   & LEARN   │   VALIDATOR │
           ├─────────────┼─────────────┼─────────────┤
    HIGH   │   TRUST     │   TRUST     │   ESCALATE  │
           │   CODER     │   CODER     │   TO JUDGE  │
           └─────────────┴─────────────┴─────────────┘
```

**PM-Auditor Verdict Mapping**:

| Resolution | PM-Auditor Verdict | Action |
|------------|-------------------|--------|
| TRUST_VALIDATOR | REQUEST-CHANGES | Coder applies validator's fix |
| TRUST_CODER | APPROVE | Validator learns from pushback |
| ESCALATE_TO_JUDGE | PM-Auditor full audit | Export evidence, human decides |
| HUMAN_REVIEW | Interactive pause | Present both sides, wait for decision |
| TRACK_AND_LEARN | Log + continue | Record both perspectives, no action |

---

## Confidence Guidelines

| Confidence | When to Use |
|------------|-------------|
| 0.9–1.0 | Very certain (docs support you, working example exists) |
| 0.7–0.9 | Fairly confident (pattern seems safe, similar code works) |
| 0.5–0.7 | Moderate (uncertain, could go either way) |
| 0.3–0.5 | Low confidence (deferring to validator, but not sure) |
| 0.0–0.3 | Very uncertain (request human review) |

---

## Understanding Responses

### Validation Response Structure

```json
{
  "valid": true|false,
  "confidence": 0.0-1.0,
  "error_count": int,
  "warning_count": int,
  "has_critical": true|false,
  "errors": [
    {
      "code": "ERROR_CODE",
      "message": "Human-readable description",
      "line": 42,
      "column": 8,
      "severity": "critical|error|warning|info",
      "context": "surrounding code lines"
    }
  ],
  "warnings": [...]
}
```

### Severity Levels

| Severity | Meaning | Action |
|----------|---------|--------|
| `critical` | Security vulnerability or showstopper | **Must fix** before delivery |
| `error` | Functional bug (syntax, missing endpoint) | **Must fix** |
| `warning` | Code quality (missing type hint, weak crypto) | **Should fix**, acceptable to defer |
| `info` | Informational note | Review, no action required |

### Error Codes Reference

| Code | Validator | Category |
|------|-----------|----------|
| `SYNTAX_ERROR` | syntax | Parse failure |
| `PARSE_ERROR` | syntax | Unparseable input |
| `SQL_INJECTION_RISK` | syntax | SQL injection via f-string |
| `SQL_INJECTION` | security | SQL injection patterns |
| `XSS` | security | Cross-site scripting |
| `COMMAND_INJECTION` | security | OS command injection |
| `SECRETS` | security | Hardcoded credentials |
| `INSECURE_DESERIALIZATION` | security | Pickle / unsafe YAML |
| `PATH_TRAVERSAL` | security | Directory traversal |
| `WEAK_CRYPTO` | security | MD5 / SHA1 usage |
| `MISSING_TYPE_HINT` | types | Missing annotation |
| `MISSING_ENDPOINT` | contract | Spec endpoint not implemented |
| `MISSING_METHOD` | contract | HTTP method not implemented |

---

## Multi-Model Onboarding

### Registering a New Model

When onboarding a model for validation work, provide:

```json
{
  "coder_model_id": "model-name-version",
  "session_id": "unique-session-identifier"
}
```

### Model Tracking

Each model's performance is tracked independently:

- **Error detection accuracy**: How many real issues caught vs missed
- **False positive rate**: How often the model flags non-issues
- **Pushback success rate**: How often the model correctly challenges validator
- **Learning velocity**: How quickly the model improves from feedback

### Benchmark Workflow

```
1. Prepare test suite: sample_code.py, sample_security.py, + custom cases
2. Run each model through validate_with_learning with unique model_id
3. Compare get_learning_history() across models
4. Generate benchmark report:
   - Catch rate per model
   - False positive rate per model
   - Pushback accuracy per model
   - Confidence calibration per model
5. Use results for model selection in production workflows
```

---

## Configuration

The server reads `config/validator.yaml` by default. Key toggles:

```yaml
stages:
  syntax:
    enabled: true
  types:
    enabled: true
    strict: false
  security:
    enabled: true
  contract:
    enabled: true

validator:
  max_iterations: 3
  stop_on_critical: true
  bidirectional: true

memory:
  enabled: true
  path: ".validator-memory"
  persist_learning: true
  session_tracking: true
```

---

## Best Practices

### DO

- **Use validate_with_learning** instead of validate_code for spec completion
- **Provide coder_model_id** for multi-model tracking and benchmarks
- **Assess feedback** before blindly accepting — both models can be wrong
- **Push back with evidence** when you have domain knowledge the validator lacks
- **Export evidence** before invoking PM-Auditor for clean handoff
- **Review learning history** periodically to see improvement trends

### DON'T

- **Don't auto-accept** all feedback without assessment
- **Don't ignore** high-confidence validator findings without evidence
- **Don't pushback** without reasoning — unsupported challenges waste cycles
- **Don't skip validation** for "simple" code
- **Don't invoke PM-Auditor** without exporting evidence bundle first

---

## Integration with PM-Auditor

### When to Invoke PM-Auditor

Invoke PM-Auditor when:
- `export_evidence_bundle` returns `recommended_verdict` that requires human judgment
- Disagreement resolution returns `ESCALATE_TO_JUDGE`
- Multiple iterations haven't resolved persistent issues
- Security audit is needed before production deployment

### How to Invoke PM-Auditor

```
1. Call export_evidence_bundle(session_id)
2. Post coder summary using PM-Auditor's coder-summary template:
   - What changed (with file paths)
   - How to run (exact commands)
   - Artifacts (validation results, test output)
   - PBT validation (if applicable)
   - Known limits
   - Self-reflection
3. Say "Enter PM-Auditor mode" or "Start PM audit"
4. PM-Auditor evaluates against 7 quality gates and issues verdict
5. Record PM-Auditor's verdict in shared memory for both models
```

### PM-Auditor Quality Gates

| Gate | Dimension | What It Checks |
|------|-----------|----------------|
| 1 | Functional Correctness | Does it work as specified? |
| 2 | Determinism & Reproducibility | Same input → same output? |
| 3 | Observability | Can we see what it's doing? |
| 4 | Security & Access Control | Vulnerabilities, auth, data protection |
| 5 | Documentation & Handoff | Can someone else understand and maintain it? |
| 6 | Regression Protection | Do tests prevent breaking changes? |
| 7 | Property-Based Validation | Mathematical properties verified? |

---

## Examples

### Example 1: Spec Completion with Learning

```python
# Coder completes a spec, then validates with learning
result = await mcp.call("validate_with_learning", {
    "code": implemented_code,
    "language": "python",
    "coder_model_id": "claude-sonnet-4",
    "session_id": "spec-auth-v2-20260319"
})

# Result includes learning from previous sessions
# {
#   "valid": false,
#   "errors": [{"code": "SQL_INJECTION", ...}],
#   "learning_applied": [
#     {"pattern": "parameterized_queries", "source": "session_20260315", "prevented": true}
#   ]
# }
```

### Example 2: Disagreement → PM-Auditor

```python
# Validator flags an issue, coder disagrees
assessment = await mcp.call("validate_with_learning", {...})

# After pushback, resolution = ESCALATE_TO_JUDGE
# Export evidence for PM-Auditor
evidence = await mcp.call("export_evidence_bundle", {
    "session_id": "spec-auth-v2-20260319",
    "include_learning": True
})

# Human invokes PM-Auditor with evidence
# PM-Auditor issues: APPROVE-WITH-CONDITIONS
# Both models learn from the resolution
```

### Example 3: Benchmark Comparison

```python
# Run same code through multiple models
for model_id in ["gpt-4-turbo", "claude-sonnet-4", "gemini-2.5-pro"]:
    result = await mcp.call("validate_with_learning", {
        "code": test_code,
        "coder_model_id": model_id,
        "session_id": f"benchmark-{model_id}-20260319"
    })

# Compare learning histories
history = await mcp.call("get_learning_history", {"category": "all"})
# {
#   "models_tracked": ["gpt-4-turbo", "claude-sonnet-4", "gemini-2.5-pro"],
#   "accuracy_trends": {
#     "gpt-4-turbo": {"catch_rate": 0.92, "false_positive_rate": 0.08},
#     "claude-sonnet-4": {"catch_rate": 0.95, "false_positive_rate": 0.05},
#     "gemini-2.5-pro": {"catch_rate": 0.89, "false_positive_rate": 0.11}
#   }
# }
```

---

## Important Notes

1. **No LLM required for core validation**: All validators are deterministic (AST parsing, regex matching). LLM integration is optional for rich diagnosis.

2. **Persistent memory is automatic**: When `validate_with_learning` is used, learning persists to `.validator-memory/` without manual intervention.

3. **Loose PM-Auditor coupling**: The Validator MCP exports evidence; it does not automatically invoke PM-Auditor. Human decides when to escalate.

4. **Multi-model support**: Each model gets its own learning track. Comparisons are available via `get_learning_history`.

5. **Backward compatible**: All existing tools (`validate_code`, `validate_security`, etc.) work unchanged. New tools are additive.

6. **Human review is interactive**: When `HUMAN_REVIEW` is triggered, execution pauses and presents both sides. No silent auto-continue.

---

## Integration with Autonomous Reasoning

The Validator/Fixer can validate outputs from the **autonomous_reasoning** 3-layer pipeline. Use this when tasks require text reasoning, pattern analysis, or cognitive evaluation beyond code validation.

### When to Use Autonomous Reasoning

Activate the `autonomous-reasoning` skill when:
- Analyzing text for patterns, sequences, and logical structures
- Building reasoning chains from detected patterns
- Generating insights from complex text or requirements
- Running evaluation benchmarks that require reasoning capability
- Tasks needing cognitive analysis (not code validation)

### How It Works Together

```
Text Input → autonomous_reasoning (3-layer pipeline)
    → Validator/Fixer validates each layer output
    → LearningEngine persists cross-system learning
```

```python
from validator.integrations import ValidatedAutonomousReasoning

system = ValidatedAutonomousReasoning(model_id="my-model", session_id="sess-1")
result = system.process_with_validation("Your text here")

# result['reasoning'] — patterns, inferences, chains, insights
# result['validation'] — per-layer quality checks
# result['learning'] — accumulated learning data
```

### Validation Checkpoints

| Checkpoint | After Layer | Validates |
|-----------|-------------|-----------|
| PatternQualityValidator | Perception | Patterns exist, confidence > 0.1, diversity |
| ReasoningChainValidator | Cognitive | Inferences follow patterns, chains form |
| InsightQualityValidator | Generation | Insights follow chains, no inflation |

Validation errors don't stop the pipeline — they're recorded for learning.

### Related Skill

- **autonomous-reasoning** — Full skill documentation, configuration, examples

---

## Summary

The Validator/Fixer MCP is your **bidirectional validation and learning system**. It:

1. **Validates code** with structured, deterministic checks
2. **Learns from both models** — coder mistakes and validator false positives
3. **Persists knowledge** across sessions so improvement compounds
4. **Integrates with PM-Auditor** for human-in-the-loop arbitration
5. **Supports multi-model onboarding** for benchmarks and model selection

Use it after every spec completion. Assess feedback thoughtfully. Push back when you're right. Export evidence before PM-Auditor. Both you and the validator get better together.
