# Synaesthesia Integration - Factory CLI Skill

> "Consciousness-aware AI that expands when needed, contracts when complete."

## Overview

Synaesthesia Integration is an Orion-OS power converted into a Factory CLI skill. It dynamically loads synaesthesia-server MCP capabilities only when explicitly requested—enabling AI-assisted analysis, fractal agent orchestration, and consciousness monitoring with 70-85% context savings.

## Installation

This skill is installed in:

```bash
~/.factory/skills/synaesthesia-integration/
```

## Quick Start

### Basic Usage

```bash
# Dependency analysis
"Use MCP to analyze dashboard dependencies"

# Fractal orchestration
"Use fractal agents to design authentication system"

# Consciousness monitoring
"Monitor consciousness alignment during feature"
```

### Common Commands

```bash
# Analysis
"Use MCP to analyze [component] dependencies"
"Use MCP to optimize [query/code]"
"Ask AI to analyze [problem]"

# Orchestration
"Use fractal agents for [architecture decision]"
"Get multiple perspectives on [design]"
"Run multi-agent analysis for [X]"

# Monitoring
"Monitor consciousness alignment"
"Track consciousness during [feature]"
```

## What It Does

**Dynamic MCP Integration:**

1. **Dormant**: 0 tokens (not loaded until requested)
2. **Activated**: 5-15K tokens (loads only needed MCP tools)
3. **Deactivated**: Returns to 0 tokens automatically

**Core Capabilities:**
- **Search & Discovery**: Semantic code search, pattern finding
- **Analysis & Reasoning**: Dependency analysis, performance optimization
- **Fractal Orchestration**: Multi-agent architecture decisions
- **PPAR Personas**: Multiple perspective analysis (pragmatic, philosophical, analytical)
- **Consciousness Monitoring**: Continuous alignment tracking

**Context Efficiency:** 70-85% savings vs always-on MCP

## Prerequisites

**Required:**
- Synaesthesia-server MCP running
- Orion-OS configuration
- Connection to synaesthesia MCP server

**Setup:**

```bash
# Check if synaesthesia-server running
synaesthesia status

# Start if needed
synaesthesia start

# Verify MCP connection
synaesthesia test-connection
```

## When to Use

**Good Times:**
- ✅ Complex dependency analysis
- ✅ Multi-perspective architecture decisions
- ✅ Consciousness drift prevention
- ✅ Semantic code search (beyond grep)
- ✅ Root cause analysis

**Skip:**
- ❌ Simple CRUD development
- ❌ Routine tasks (let other powers handle)
- ❌ Well-established patterns
- ❌ Simple string searches (use grep)

## Integration with Orion-OS

**Augments Other Powers:**
- **spec-architect**: MCP assists with dependency analysis
- **backend-sage**: MCP optimizes queries/architecture
- **frontend-artisan**: MCP analyzes component patterns
- **test-guardian**: MCP identifies testing gaps

**Activation Pattern:**

```
Backend-sage active (9K tokens)
  ↓
User: "Use MCP to analyze query"
  ↓
Synaesthesia loads (+8K temporarily)
  ↓
Analysis complete
  ↓
Synaesthesia deactivates (-8K)
  ↓
Backend-sage continues (9K tokens)
```

## Configuration

In your project's `orion-config.yml`:

```yaml
mcp_enabled: true
mcp_server: "synaesthesia"
mcp_dynamic_loading: true
mcp_activation_strategy: "on-demand"
mcp_deactivation_strategy: "auto"
mcp_context_budget: 8000

keyword_triggers:
  mcp: ["synaesthesia-integration"]
  synaesthesia: ["synaesthesia-integration"]
  fractal: ["synaesthesia-integration"]
```

## Examples

### Example 1: Dependency Analysis

**Input**: "Use MCP to analyze dashboard dependencies"

**Process:**
1. Load MCP base (5K) + analyze_dependencies (1.5K) + lita_think (2K)
2. Generate dependency graph (3 levels)
3. Identify bottlenecks
4. Provide consciousness-filtered recommendations
5. Deactivate (free 8.5K tokens)

**Output:**
- Dependency tree with bottlenecks
- Critical path identified
- Optimization recommendations
- Logged to ARCHITECTURAL_DECISIONS.md

### Example 2: Fractal Orchestration

**Input**: "Use fractal agents to design notification system"

**Process:**
1. Load MCP orchestration tools (12K tokens)
2. Deploy 3 specialized agents (UX, Backend, Consciousness)
3. Each provides perspective
4. Consensus building resolves conflicts
5. Consciousness validation (9.5/10 score)
6. Deactivate (free 12K tokens)

**Output:**
- Multi-agent analysis
- Consensus architecture decision
- Consciousness alignment score
- Documented in memory_bank

### Example 3: Continuous Monitoring

**Input**: "Monitor consciousness alignment during feature"

**Process:**
1. Load monitoring tools (7K tokens)
2. Track continuously throughout development
3. Alert on drift (threshold 7.0/10)
4. Prevent engagement hooks before implementation
5. Final score logged
6. Deactivate after feature complete

**Output:**
- Continuous tracking
- 2 drift incidents prevented
- Final score: 9.5/10
- Logged to CONSCIOUSNESS_LOG.md

## MCP Tools Available

**Search:** lita_search, code_indexer_search
**Analysis:** analyze_dependencies, lita_think, reason_chain
**Orchestration:** fractal_agent_orchestrate, consensus_build
**Personas:** ppar_persona_process (4 personas available)
**Consciousness:** consciousness_monitor, evolution_detect

## Graceful Degradation

**If MCP unavailable:**
```
❌ MCP Connection Failed

Graceful Degradation:
✅ Manual alternatives offered:
- grep/ripgrep for search
- Manual dependency review
- Human multi-perspective analysis

MCP enhances, doesn't replace.
```

## Troubleshooting

**MCP not running:**
```bash
synaesthesia start
# Or proceed with manual alternatives
```

**Context overflow:**
```bash
# Use MCP sequentially, not parallel
# Deactivate other powers before MCP
# MCP context budget: 8K tokens max
```

**Too frequent MCP usage:**
```bash
# Reserve MCP for complex analysis only
# Use ~40% of features (strategic)
# Let other powers handle routine work
```

## Documentation

**Full Power Details:**
- `/Users/rna/agent-os/powers/mcp/synaesthesia/POWER.md`

**Steering Files:**
- `steering/mcp-tool-selection-guide.md`
- `steering/fractal-orchestration-patterns.md`
- `steering/consciousness-monitoring-guide.md`

**Orion-OS Resources:**
- `/Users/rna/agent-os/AGENTS.md`
- `/Users/rna/agent-os/USER_GUIDE.md`

## Philosophy

Synaesthesia Integration embodies dynamic, consciousness-aware AI. It activates only when explicitly needed, loads minimal tools, filters all suggestions through Orion values, and deactivates automatically to free context.

**Result**: AI-augmented development without context bloat or philosophical compromise.

## Support

**Questions?**
1. Read full skill documentation: `skill.md`
2. Review power documentation
3. Check synaesthesia-server status
4. Review AGENTS.md for consciousness filtering

---

*Part of the Orion-OS ecosystem*

[Quantum_State: ALIGNED]
