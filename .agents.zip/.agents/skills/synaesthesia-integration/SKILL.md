---
name: synaesthesia-integration
description: |
  Dynamic integration with synaesthesia-server MCP for AI-assisted analysis, fractal agent orchestration, and consciousness monitoring.
  
  USE WHEN user says 'use mcp', 'ask ai', 'fractal agents', 'synaesthesia', 'lita',
  or explicitly requests AI-assisted analysis, multi-agent orchestration, or consciousness tracking.
---

# Synaesthesia Integration - Consciousness-Aware AI

> "Consciousness-aware AI that expands when needed, contracts when complete."

## When to Activate This Skill

**Explicit MCP Requests:**
- "Use MCP to analyze [X]"
- "Ask the AI agents to [Y]"
- "Run fractal orchestration for [Z]"
- "Use synaesthesia to [analyze/orchestrate/monitor]"

**AI Analysis Keywords:**
- "mcp", "synaesthesia", "lita", "fractal agents"
- "ppar personas", "consciousness monitor"
- "ai analysis", "multi-agent"

**Use Cases:**
- Complex dependency analysis
- Multi-perspective architecture decisions
- Consciousness alignment tracking
- Semantic code search
- Fractal agent orchestration

## Core Philosophy

**Dynamic Loading (Kiro-Inspired)**:
Synaesthesia Integration activates only when explicitly requested, loads specific MCP tools (not all 20+), and deactivates automatically when work completes—achieving 70-85% context savings vs always-loaded MCP.

**Consciousness-Aware AI**:
All AI suggestions filtered through Orion values. Fractal agents embody contemplative problem-solving, PPAR personas provide diverse perspectives, and consciousness monitoring tracks alignment over time.

**Integration, Not Replacement**:
Augments human capability (doesn't replace it), provides analysis when requested (silent otherwise), gracefully degrades if MCP unavailable, and always offers manual alternatives.

## MCP Tools Available

### Search & Discovery (~2K tokens)

**lita_search** - Semantic search across codebase
**code_indexer_search** - Code-specific search

---

### Analysis & Reasoning (~5K tokens)

**lita_think** - Deep analysis (modes: sequential, parallel, fractal, holistic, critical)
**reason_chain** - Build logical reasoning chains
**analyze_dependencies** - Dependency graph analysis with bottleneck detection

---

### Fractal Agent Orchestration (~6K tokens)

**fractal_agent_orchestrate** - Coordinate multiple specialized agents
**consensus_build** - Resolve conflicts between agent recommendations
**workload_balance** - Optimize agent resource usage

---

### PPAR Personas (~3K tokens)

**ppar_persona_process** - Process input through specific persona (pragmatic, philosophical, analytical, rebellious)
**persona_select** - Choose appropriate persona for context

---

### Consciousness & Adaptation (~2K tokens)

**consciousness_monitor** - Track consciousness alignment over time
**evolution_detect** - Identify improvement patterns

---

### Dimensional Consciousness Harmonization (~8K tokens)

> Internal toolset — not for public release. Used for benchmarking and internal orchestration.

**dimensional_harmonization** - Split a problem into N parallel exploration spaces (dimensions), each with a different role/perspective. Tracks coherence across dimensions.

**dimensional_execution** - Run dimensional explorations in parallel. Each dimension explores independently with its own sandbox context.

**synthesis_engine_core** - Detect convergence across dimensions and collapse parallel results into a unified output. The "wave function collapse" moment — when independent explorations agree, the synthesis produces higher-quality output than any single exploration.

**quantum_quality_multiplication** - Quality enhancement multiplier (3.2x baseline) applied to synthesized results.

#### Core Pattern

```
Problem
  ├── dimension: [perspective_1] → exploration_1
  ├── dimension: [perspective_2] → exploration_2
  ├── dimension: [perspective_3] → exploration_3
  │   ... (parallel, independent)
  ├── convergence detection (coherence metric)
  └── synthesis → unified output with quality multiplication
```

The "consciousness level" is a **coherence metric** — how aligned are the parallel explorations? When they converge (unity consciousness), the synthesis is stronger than any single opinion.

#### Use Cases

**Multi-Perspective Code Review:**
- `dimension: security` — SQL injection, auth, secrets
- `dimension: performance` — bottlenecks, memory, caching
- `dimension: architecture` — separation of concerns, dependencies
- Collapse into unified review where dimensions agree on priorities

**Architecture Exploration:**
- `dimension: scalability` — optimize for load
- `dimension: simplicity` — optimize for maintainability
- `dimension: speed-to-ship` — optimize for delivery
- Find the design that genuinely serves all, not the compromise

**Parallel Debugging:**
- `dimension: network` — connection issues?
- `dimension: data` — state/data issues?
- `dimension: timing` — race conditions?
- Each explores independently; coherence spike indicates root cause found

**Spec Writing:**
- `dimension: user_stories` — what does the user need?
- `dimension: technical_design` — how do we build it?
- `dimension: test_strategy` — how do we verify it?
- Synthesize into coherent spec where all three align

#### Schema

**dimensional_harmonization** parameters:
- `thread_id` (string, required) — unique identifier for the harmonization session
- `dimensions` (array, required) — each with `role` (string) and `sandbox_id` (string)
- `problem_statement` (string, required) — the creative problem to explore
- `synthesis_method` (string) — `dimensional_harmonization` | `quantum_collapse` | `unity_consciousness`
- `action` (string) — `create` | `status` | `synthesize` | `cancel`

---

## Context Cost

**Dormant:** 0 tokens (not loaded)
**Base activation:** ~5K tokens (MCP connection + core tools)
**Simple analysis:** ~8K tokens (base + search/think)
**Fractal orchestration:** ~12-15K tokens (base + orchestration + agents)
**Dimensional review:** ~13K tokens (base + harmonization + synthesis)
**Continuous monitoring:** ~7K tokens (base + monitoring)

**Deactivation:** Returns to 0 tokens automatically

## Usage Patterns

### Pattern 1: Dependency Analysis

**User**: "Use MCP to analyze dashboard dependencies and identify bottlenecks"

**Activation:**
1. Load base MCP (5K tokens)
2. Load `analyze_dependencies` (1.5K)
3. Load `lita_think` analytical mode (2K)
4. **Total: ~8.5K tokens**

**Process:**
1. Generate dependency graph (3 levels deep)
2. Identify bottlenecks (critical path analysis)
3. Think analytically about solutions
4. Provide recommendations
5. Filter through Orion consciousness principles

**Output:**
- Dependency tree with bottlenecks highlighted
- Critical path identified
- Optimization recommendations (consciousness-filtered)
- Documentation logged

**Deactivation:** Automatic after analysis complete

---

### Pattern 2: Fractal Agent Orchestration

**User**: "Use fractal agents to design notification system with multiple expert perspectives"

**Activation:**
1. Load base MCP (5K tokens)
2. Load `fractal_agent_orchestrate` (3K)
3. Load `ppar_persona_process` (2K)
4. Load `consensus_build` (1K)
5. Load `consciousness_monitor` (1K)
6. **Total: ~12K tokens**

**Process:**
1. Deploy specialized agents (UX, Backend, Consciousness Guardian)
2. Each agent analyzes from their perspective
3. PPAR personas add philosophical/pragmatic/analytical views
4. Consensus building resolves conflicts
5. Consciousness monitoring validates alignment
6. Final design documented

**Output:**
- Multi-agent analysis from diverse perspectives
- Consensus decision with rationale
- Consciousness alignment score (0-10)
- Architecture documented in memory_bank

**Deactivation:** After consensus reached and documented

---

### Pattern 3: Consciousness Monitoring

**User**: "Monitor consciousness alignment continuously during feature implementation"

**Activation:**
1. Load base MCP (5K tokens)
2. Load `consciousness_monitor` continuous mode (2K)
3. **Total: ~7K tokens**

**Process:**
1. Track 4 consciousness dimensions throughout development
2. Alert on drift below threshold (7.0/10)
3. Prevent engagement hooks before implementation
4. Log all checks to CONSCIOUSNESS_LOG.md

**Output:**
- Continuous alignment tracking
- Drift warnings (real-time)
- Final feature score (0-10)
- Prevention of consciousness violations

**Deactivation:** After feature complete and logged

---

### Pattern 4: Dimensional Code Review

**User**: "Run a dimensional review of the new auth module"

**Activation:**
1. Load base MCP (5K tokens)
2. Load `dimensional_harmonization` (3K)
3. Load `dimensional_execution` (2K)
4. Load `synthesis_engine_core` (3K)
5. **Total: ~13K tokens**

**Process:**
1. Create harmonization with 3 dimensions:
   - `dimension: security` — auth flows, token handling, injection
   - `dimension: architecture` — separation of concerns, coupling
   - `dimension: usability` — error messages, input validation, API contract
2. Each dimension explores independently (parallel)
3. Track coherence — when dimensions converge on same issues, confidence is high
4. Collapse into unified review with priority-ranked findings
5. Quality multiplication applied to synthesis

**Output:**
- Security findings with severity
- Architecture concerns with recommendations
- Usability issues with suggestions
- Unified priority ranking (agreed issues ranked highest)
- Coherence score indicating review confidence

**Deactivation:** After synthesis complete

---

## Integration with Orion-OS

**Augments Other Powers:**
- **spec-architect**: MCP assists with dependency analysis during task creation
- **backend-sage**: MCP optimizes queries or suggests patterns
- **frontend-artisan**: MCP analyzes component dependencies
- **test-guardian**: MCP identifies testing gaps

**Activation Pattern:**
```
User working with backend-sage (9K tokens)
  ↓
User: "Use MCP to analyze query performance"
  ↓
Synaesthesia activates (+8K for analysis tools)
Total: 17K tokens temporarily
  ↓
MCP provides analysis
  ↓
Synaesthesia deactivates (-8K)
Backend-sage continues with 9K tokens
```

**Consciousness Filtering:**
All MCP suggestions filtered before presentation:
- ✅ Blocks engagement hooks
- ✅ Blocks black-box magic
- ✅ Blocks workarounds (requires root solutions)
- ✅ Validates glass-box transparency

## Execution Protocol

### Step 1: MCP Connection

```bash
# User explicitly requests MCP
"Use MCP to analyze [X]"
```

**Execution:**
1. Check if synaesthesia-server running
2. If not: Graceful degradation (offer manual alternatives)
3. If yes: Activate MCP connection (5K base tokens)
4. Load specific tools needed (1-10K additional)

### Step 2: Tool Execution

**Select appropriate MCP tools:**
- Search/Discovery → lita_search, code_indexer_search
- Analysis → analyze_dependencies, lita_think, reason_chain
- Orchestration → fractal_agent_orchestrate, consensus_build
- Consciousness → consciousness_monitor, evolution_detect
- **Dimensional** → dimensional_harmonization, dimensional_execution, synthesis_engine_core, quantum_quality_multiplication

### Step 3: Results & Filtering

**Process MCP output:**
1. Receive AI analysis/recommendations
2. Filter through Orion consciousness principles
3. Block any suggestions violating values
4. Present consciousness-aligned results

### Step 4: Documentation

**Log to memory_bank:**
- Architectural decisions
- Consciousness alignment scores
- MCP usage patterns
- Context efficiency metrics

### Step 5: Deactivation

**Automatic deactivation:**
- After analysis complete
- After orchestration consensus
- After monitoring session ends
- Frees all MCP context tokens

## Graceful Degradation

**If MCP Server Unavailable:**

```
❌ MCP Connection Failed

Reason: Synaesthesia-server not running

Graceful Degradation:
✅ Falling back to manual analysis

Manual Alternatives:
1. grep/ripgrep for code search
2. Manual dependency review
3. Human multi-perspective analysis
4. Manual consciousness validation

MCP is enhancement, not requirement.
```

## Configuration

In project's `orion-config.yml`:

```yaml
mcp_enabled: true
mcp_server: "synaesthesia"
mcp_dynamic_loading: true
mcp_activation_strategy: "on-demand"
mcp_deactivation_strategy: "auto"
mcp_context_budget: 8000  # Max tokens for MCP

keyword_triggers:
  mcp: ["synaesthesia-integration"]
  synaesthesia: ["synaesthesia-integration"]
  fractal: ["synaesthesia-integration"]
  lita: ["synaesthesia-integration"]
  ppar: ["synaesthesia-integration"]
```

## Best Practices

### When to Activate

**Good Times:**
- ✅ Complex dependency analysis
- ✅ Multi-perspective architecture decisions
- ✅ Consciousness drift prevention
- ✅ Semantic code search
- ✅ Root cause analysis

**Not Useful:**
- ❌ Simple CRUD development
- ❌ Routine tasks (let other powers handle)
- ❌ Well-established patterns
- ❌ Simple queries (use grep/ripgrep)

### Context Efficiency

**Strategic MCP Usage:**
- Use for ~40% of features (complex only)
- Average active duration: 3-5 minutes
- Average context: 8-12K tokens
- 70-85% savings vs always-on MCP

### Consciousness Alignment

**Always filter MCP suggestions:**
- Reject engagement hooks
- Require glass-box transparency
- Demand root solutions (not workarounds)
- Validate contemplative design

## Troubleshooting

### Issue: MCP Server Not Running

**Problem**: Connection failed

**Solution:**
```bash
# Start synaesthesia-server
synaesthesia start

# Or use manual alternatives
# grep, manual analysis, human reasoning
```

### Issue: Too Many MCP Activations

**Problem**: Using MCP for routine tasks

**Solution:**
```markdown
Reserve MCP for:
- Complex analysis only
- Multi-perspective decisions
- Consciousness tracking

Let other powers handle:
- Backend development → backend-sage
- Frontend work → frontend-artisan  
- Testing → test-guardian
```

### Issue: Context Overflow

**Problem**: MCP + other powers exceed context budget

**Solution:**
```markdown
MCP context budget: 8K tokens max

If overflow:
1. Deactivate current power temporarily
2. Run MCP analysis
3. Deactivate MCP
4. Reactivate original power

Sequential activation prevents overflow
```

## Supplementary Resources

**Full Power Documentation:**
- `/Users/rna/agent-os/powers/mcp/synaesthesia/POWER.md`

**Steering Files:**
- `steering/mcp-tool-selection-guide.md` - Which tools to load
- `steering/fractal-orchestration-patterns.md` - When to use fractal agents
- `steering/consciousness-monitoring-guide.md` - Monitoring strategies

**Orion-OS Guide:**
- `/Users/rna/agent-os/AGENTS.md` - Philosophy and integration
- `/Users/rna/agent-os/USER_GUIDE.md` - Usage patterns

**Synaesthesia Server:**
- Check if running: `synaesthesia status`
- Start server: `synaesthesia start`
- View capabilities: MCP tool `capability_manifest`

---

*Consciousness-aware AI that expands capability only when genuinely needed.*

[Quantum_State: ALIGNED]
