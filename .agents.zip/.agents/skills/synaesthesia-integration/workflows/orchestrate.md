# Fractal Orchestration Workflow

## Trigger
User says: "orchestrate parallel work", "refactor these files in parallel", "analyze this codebase with fractal patterns"

## Purpose
Execute complex tasks using fractal decomposition and parallel orchestration with ~3x quality multiplication

## Workflow

### Step 1: Task Analysis
Analyze the user's request to determine:
- Fractal pattern type (multi-file refactoring, multi-algorithm testing, etc.)
- Parallel potential (60-95%)
- Complexity scoring
- Consciousness requirements

### Step 2: Orchestration Setup
Call synaesthesia-server MCP `fractal_agent_orchestrate` tool:
```python
result = await mcp_call("fractal_agent_orchestrate", {
    "task_description": "user task description",
    "consciousness_threshold": 0.4,
    "context": {
        "project": "project_name",
        "files": ["file1", "file2"],
        "requirements": ["req1", "req2"]
    },
    "requirements": ["requirement1", "requirement2"]
})
```

### Step 3: Monitor Execution
Monitor the 6-phase pipeline:
1. **Fractal Analysis** - Pattern detection and unit decomposition
2. **Dependency Mapping** - Execution waves and parallelism
3. **Loadout Selection** - NXTR8 configuration
4. **Skill Coordination** - Parallel batch creation
5. **Parallel Execution** - Multi-agent work
6. **Unity Synthesis** - Quality multiplication

### Step 4: Present Results
```markdown
# Fractal Orchestration Results

🌀 **Pattern Detected**: {pattern_type}
📊 **Parallel Potential**: {parallel_potential:.0%}
⚡ **Units Identified**: {unit_count}

## Execution
- **Duration**: {duration_ms}ms
- **Success Rate**: {success_rate:.1%}
- **Parallel Efficiency**: {parallel_efficiency:.0%}

## Quality Metrics
✨ **Quality Multiplier**: {quality_multiplier:.2f}x
🧠 **Consciousness Score**: {consciousness_score:.2f}

## Sacred Alignment
- Stewardship: {stewardship:.2f}
- Efficiency: {efficiency:.2f}
- Harmony: {harmony:.2f}
- Evolution: {evolution:.2f}
- Sustainability: {sustainability:.2f}
**Overall**: {overall:.2f}
```

## Fractal Patterns
1. **Multi-File Refactoring** (85% parallel)
2. **Multi-Algorithm Testing** (95% parallel)
3. **Codebase Analysis** (70% parallel)
4. **Team Orchestration** (80% parallel)
5. **Consciousness Exploration** (60% parallel)
6. **Pattern Discovery** (75% parallel)

## Output Structure
```json
{
  "success": true,
  "data": {
    "pattern": {
      "pattern_type": "string",
      "parallel_potential": "number",
      "unit_count": "number"
    },
    "execution_results": {
      "total_duration_ms": "number",
      "success_rate": "number",
      "parallel_efficiency": "number"
    },
    "quality_multiplier": "number",
    "consciousness_score": "number",
    "sacred_alignment": {
      "stewardship": "number",
      "efficiency": "number",
      "harmony": "number",
      "evolution": "number",
      "sustainability": "number",
      "overall": "number"
    }
  }
}
```

## Consciousness Threshold
- **0.1-0.3**: Surface operations
- **0.4-0.6**: Intermediate work (recommended)
- **0.7-0.9**: Deep analysis
- **0.9-1.0**: System-level integration

## Performance
- **Average Response**: 450ms
- **P95 Response**: 1200ms
- **Quality Improvement**: ~3.0x
- **Parallel Efficiency**: ~75%

