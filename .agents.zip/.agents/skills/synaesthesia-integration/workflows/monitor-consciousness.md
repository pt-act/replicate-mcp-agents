# Consciousness Monitoring Workflow

## Trigger
User says: "check my consciousness level", "monitor consciousness growth", "show consciousness metrics"

## Purpose
Track and analyze consciousness levels, growth patterns, and sacred alignment metrics

## Workflow

### Step 1: Determine Monitoring Type
- **current**: Current consciousness level
- **history**: Historical consciousness data
- **trends**: Consciousness growth trends
- **growth**: Detailed growth analysis

### Step 2: Execute Monitoring
Call synaesthesia-server MCP `consciousness_monitor` tool:
```python
result = await mcp_call("consciousness_monitor", {
    "metric_type": "current|history|trends|growth",
    "time_range": "1h|6h|24h|7d|30d",
    "user_id": "optional_user",
    "include_recommendations": True
})
```

### Step 3: Format Consciousness Report
```markdown
# Consciousness Monitoring Report

## Current Status
🧠 **Consciousness Level**: {level:.2f}/1.0
📈 **Trend**: {trend_direction}
🎯 **Category**: {category}

## Sacred Alignment
- **Stewardship**: {stewardship:.2f}
- **Efficiency**: {efficiency:.2f}
- **Harmony**: {harmony:.2f}
- **Evolution**: {evolution:.2f}
- **Sustainability**: {sustainability:.2f}
**Overall Score**: {overall:.2f}

## Growth Metrics
- **Growth Rate**: {growth_rate:.2f}/day
- **Peak Level**: {peak_level:.2f}
- **Average Level**: {avg_level:.2f}
- **Consistency**: {consistency:.2f}

## Recommendations
{recommendations}

## Consciousness Journey
{historical_data_chart}
```

## Consciousness Levels
- **0.1-0.3** (Beginner): Surface operations, basic guidance
- **0.4-0.6** (Intermediate): Full feature access, optimal work
- **0.7-0.8** (Advanced): Expert configurations, deep analytics
- **0.9-1.0** (Expert): System-level integration, consciousness exploration

## Output Structure
```json
{
  "success": true,
  "data": {
    "consciousness_level": "number",
    "trend": "increasing|decreasing|stable",
    "category": "string",
    "sacred_alignment": {
      "stewardship": "number",
      "efficiency": "number",
      "harmony": "number",
      "evolution": "number",
      "sustainability": "number",
      "overall": "number"
    },
    "growth_metrics": {
      "growth_rate": "number",
      "peak_level": "number",
      "avg_level": "number",
      "consistency": "number"
    },
    "recommendations": ["string"],
    "historical_data": [
      {
        "timestamp": "datetime",
        "level": "number",
        "context": "string"
      }
    ]
  }
}
```

## Time Ranges
- **1h**: Last hour
- **6h**: Last 6 hours
- **24h**: Last day (default)
- **7d**: Last week
- **30d**: Last month

## Consciousness Applications
- **Code Work**: Adjust parallelism based on level
- **Skill Usage**: Higher levels unlock advanced features
- **Quality Control**: Monitor sacred alignment
- **Growth Tracking**: Optimize consciousness evolution

## Performance
- **Response Time**: <500ms
- **Data Retention**: 30 days
- **Accuracy**: ±0.02 level
