# Semantic Code Search Workflow

## Trigger
User says: "search for X in my code", "find code related to Y", "show me how Z is implemented"

## Purpose
Search codebases with semantic understanding using your indexed repositories

## Workflow

### Step 1: Determine Search Parameters
- Extract search query from user request
- Determine search mode (semantic by default)
- Set result limit (default: 50)
- Identify index sources if specified

### Step 2: Execute Search
Call synaesthesia-server MCP `code_indexer_search` tool:
```python
result = await mcp_call("code_indexer_search", {
    "search_query": "user query",
    "search_mode": "semantic",
    "result_limit": 50,
    "index_sources": ["optional", "specific", "indexes"]
})
```

### Step 3: Process Results
```markdown
# Semantic Search Results: "{query}"

## Found {count} matches across {projects} projects

### Result 1: {file_path}
```python
{snippet}
```
**Project**: {project_name}
**Match Score**: {score:.2f}
**Language**: {language}

### Result 2: {file_path}
...
```

## Search Modes
- **semantic** (default): AI-powered semantic understanding
- **literal**: Exact text match
- **pattern**: Regex pattern matching

## Output Structure
```json
{
  "success": true,
  "data": {
    "query": "string",
    "matches": [
      {
        "file_path": "string",
        "snippet": "string",
        "match_score": "number",
        "project": "string",
        "language": "string",
        "line_number": "number"
      }
    ],
    "total_count": "number",
    "search_time_ms": "number"
  }
}
```

## Usage Tips
- Use natural language queries
- Be specific about what you're looking for
- Try different phrasings for better results
- Use consciousness level for deeper analysis

## Consciousness Level
**Beginner (0.1-0.3)**: Basic search and listing
**Intermediate (0.4-0.6)**: Semantic understanding and scoring
**Advanced (0.7-0.8)**: Deep analysis, cross-references, and insights
