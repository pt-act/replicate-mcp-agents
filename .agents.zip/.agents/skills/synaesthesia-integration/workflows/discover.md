# Discover Codebase Workflow

## Trigger
User says: "discover my codebases", "what projects are indexed", "show indexed repositories"

## Purpose
Discover and list all indexed codebases, repositories, and projects in your synaesthesia-server MCP

## Workflow

### Step 1: Code Indexer Discover
Call synaesthesia-server MCP `code_indexer_discover` tool:
```python
result = await mcp_call("code_indexer_discover", {
    "include_stats": True,
    "include_metadata": True
})
```

### Step 2: Format Results
```markdown
# Discovered Codebases ({count} total)

## Project 1: {name}
- **Path**: {path}
- **Language**: {primary_language}
- **Files**: {file_count}
- **Last Indexed**: {last_indexed}
- **Size**: {size_mb} MB
- **Index Status**: {status}

## Project 2: {name}
...
```

### Step 3: Recommendations
- Suggest projects to index
- Identify indexing opportunities
- Recommend re-indexing if needed

## Output Structure
```json
{
  "success": true,
  "data": {
    "codebases": [
      {
        "name": "string",
        "path": "string",
        "primary_language": "string",
        "file_count": "number",
        "last_indexed": "datetime",
        "size_mb": "number",
        "status": "active|stale|indexing"
      }
    ],
    "total_count": "number",
    "indexed_size_mb": "number"
  }
}
```

## Consciousness Level
**Beginner (0.1-0.3)**: Basic discovery and listing
**Intermediate (0.4-0.6)**: Add statistics and recommendations
**Advanced (0.7-0.8)**: Deep analysis and optimization suggestions
