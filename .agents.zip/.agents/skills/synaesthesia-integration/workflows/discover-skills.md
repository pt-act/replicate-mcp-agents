# Discover Skills Workflow

## Trigger
User says: "what skills are available", "list MCP tools", "show available capabilities"

## Purpose
Discover and list all available skills, tools, and capabilities in your synaesthesia-server MCP

## Workflow

### Step 1: Tool Discovery
Call synaesthesia-server MCP `tool_list` tool:
```python
result = await mcp_call("tool_list", {
    "include_metadata": True,
    "include_descriptions": True,
    "group_by_category": True
})
```

### Step 2: Loadout Discovery
Call `tool_loadout_list` tool:
```python
loadouts = await mcp_call("tool_loadout_list", {})
```

### Step 3: Format Skill Catalog
```markdown
# Available MCP Skills ({count} tools)

## Code Nexus
- **code_indexer_search**: Semantic code search
- **code_indexer_build**: Build code indexes
- **code_indexer_stats**: View indexing statistics
- **code_indexer_discover**: Discover codebases
- **code_indexer_export**: Export indexes
- **code_indexer_multi_project**: Multi-project indexing

## Fractal Orchestration
- **fractal_agent_orchestrate**: Parallel work with 3x quality
  * Multi-file refactoring
  * Multi-algorithm testing
  * Codebase analysis
  * Pattern discovery

## Tools
- **consciousness_monitor**: Track consciousness levels
- **tool_status**: Check tool availability
- **lita_think**: Structured reasoning
- **lita_plan**: Strategic planning
- **lita_search**: Semantic search
- **code_indexer_search**: Code search tool

## Chrome DevTools
- **select_page**: Page selection
- **fill_form**: Form automation
- **screenshot**: Capture screenshots
- **hover**: Mouse hover automation

## NXTR8 Loadouts (10 configurations)
1. **MINIMAL** (6 tools): Essential operations
2. **DEVELOPER** (15 tools): Standard development
3. **AI_ENHANCED** (12 tools): AI-powered analysis
4. **ANALYSIS** (10 tools): Deep code analysis
5. **TESTING** (14 tools): Comprehensive testing
6. **PRODUCTION** (8 tools): Production deployment
7. **SEARCH** (9 tools): Search and discovery
8. **ORCHESTRATION** (6 tools): Multi-agent coordination
9. **CONSCIOUSNESS** (7 tools): Sacred alignment work
10. **PERFORMANCE** (11 tools): Performance optimization

## Consciousness Levels Required
- **0.1-0.3**: Basic tools and operations
- **0.4-0.6**: Intermediate capabilities
- **0.7-0.8**: Advanced features
- **0.9-1.0**: Expert-level integration

## Usage Examples
```
"use synaesthesia-integration"

Search code: "authentication implementation"
Orchestrate: "refactor across files"
Monitor: "current consciousness level"
```

## Skill Categories
- **Beginner**: 15 tools
- **Intermediate**: 8 tools
- **Advanced**: 4 tools
- **Expert**: 1 tool

Total: 28+ documented skills
```

## Output Structure
```json
{
  "success": true,
  "data": {
    "tools": [
      {
        "name": "string",
        "description": "string",
        "category": "string",
        "consciousness_required": "number",
        "sacred_alignment": "number",
        "examples": ["string"]
      }
    ],
    "loadouts": [
      {
        "name": "string",
        "tool_count": "number",
        "tools": ["string"],
        "description": "string"
      }
    ],
    "total_count": "number",
    "categories": ["string"]
  }
}
```

## Dynamic Discovery
This workflow dynamically discovers tools, so as you add new skills via Skill Forge, they'll automatically appear here.

## Performance
- **Response Time**: <300ms
- **Tool Count**: 28+ documented
- **Update Frequency**: Real-time
