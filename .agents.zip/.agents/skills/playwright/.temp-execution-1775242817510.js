const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });

  const demoPath = '/Users/rna/Desktop/SolarPlex_Arbitrum-MCP/terminal-demo.html';
  await page.goto('file://' + demoPath);

  // Wait for demo to start animating
  await page.waitForTimeout(2000);

  // Capture at key moments
  const checkpoints = [
    { time: 3000, name: '01-health-check' },
    { time: 5000, name: '02-gmx-prices' },
    { time: 8000, name: '03-erc8004-registration' },
    { time: 11000, name: '04-cross-chain-reputation' },
    { time: 14000, name: '05-quadratic-voting' },
    { time: 17000, name: '06-security-status' },
    { time: 20000, name: '07-natural-language-chat' },
    { time: 23000, name: '08-complete-walkthrough' },
  ];

  for (const cp of checkpoints) {
    await page.waitForTimeout(cp.time - (checkpoints.indexOf(cp) > 0 ? checkpoints[checkpoints.indexOf(cp) - 1].time : 0));
    await page.screenshot({ path: `/tmp/terminal-${cp.name}.png`, fullPage: false });
    console.log(`✅ Captured: ${cp.name}`);
  }

  // Final full page
  await page.screenshot({ path: '/tmp/terminal-full-demo.png', fullPage: true });
  console.log('✅ Captured: full-demo');

  await browser.close();
  console.log('\n🎬 Terminal demo complete — screenshots saved to /tmp/');
})();
