# Spec-Architect Skill

> "Deep thinking before building. Elegant architecture emerges from conscious planning."

## Overview

Spec Architect guides requirements gathering, spec creation, and task breakdown with consciousness-driven planning before any code is written.

## Installation

This skill is installed in:

```bash
~/skills/spec-architect/
```

## Quick Start

### Basic Usage

```bash
# Plan a new feature
"Let's plan user dashboard feature"

# Write specification
"Write spec for user dashboard"

# Create task breakdown
"Create tasks for user dashboard"
```

### Common Commands

```bash
# Planning Phase
"Plan [feature-name]"
"Gather requirements for [X]"
"Design [system]"

# Specification Phase
"Write spec for [feature]"
"Create specification"

# Task Breakdown Phase
"Break down into tasks"
"Create tasks for [feature]"
"Show dependencies"
```

## What It Does

**3-Phase Process:**

1. **Shape the Spec (Planning)**: Gathers requirements, analyzes visuals, searches for reusable code, creates planning artifacts
2. **Write the Spec (Specification)**: Consciousness alignment check (Gate 1), creates scannable spec.md with goal/requirements/scope
3. **Create Tasks (Task Breakdown)**: Maps dependencies, identifies parallelization, generates tasks.md with focused testing approach

**File Mappings:**
- Phase 1 → `specs/[feature]/planning/requirements.md`
- Phase 2 → `specs/[feature]/spec.md`
- Phase 3 → `specs/[feature]/tasks.md`

## Prerequisites

**Required:**
- Orion-OS spec directory structure
- Orion-OS configuration (`orion-config.yml`)
- Project memory_bank for pattern reuse

**Setup if needed:**

```bash
mkdir -p specs/
mkdir -p memory_bank/
```

## When to Use

**Good Times:**
- ✅ Starting any new feature development
- ✅ Complex features requiring coordination
- ✅ Multiple developers need clear tasks
- ✅ Want to identify reusable code patterns
- ✅ Need parallelization strategy

**Skip:**
- ❌ Simple bug fixes
- ❌ Trivial changes
- ❌ Code refactoring (different workflow)

## Integration with Orion-OS

**Works with:**
- **consciousness**: Validates alignment at Gate 1
- **memory-keeper**: Loads recent feature patterns
- **backend-sage**: Receives backend tasks
- **frontend-artisan**: Receives frontend tasks

**Workflow:**

```
Planning → Consciousness Gate 1 → Task Creation
  ↓
backend-sage (backend tasks) + frontend-artisan (frontend tasks)
```

## Configuration

In your project's `orion-config.yml`:

```yaml
phase_powers:
  planning:
    - spec-architect
  specification:
    - spec-architect

keyword_triggers:
  spec: ["spec-architect"]
  planning: ["spec-architect"]
```

## Examples

### Example 1: Dashboard Planning

**Input**: "Plan user dashboard with focus-first design"

**Output:**
- `specs/user-dashboard/planning/requirements.md`
- `specs/user-dashboard/spec.md` (2 user stories, 6 requirements)
- `specs/user-dashboard/tasks.md` (4 task groups, 15 subtasks, 8 iterations)

### Example 2: API Design

**Input**: "Write spec for notification system"

**Output:**
- Spec with WebSocket pattern
- User-controlled connections (Orion philosophy)
- Clear dependency mapping
- 6 iteration estimate

## Troubleshooting

**Dependencies unclear:**
```bash
Create explicit dependency graph in tasks.md
Map "Group X depends on Group Y"
```

## Documentation

**Orion-OS Resources:**
- `/Users/rna/agent-os/AGENTS.md`
- `/Users/rna/agent-os/USER_GUIDE.md`

## Philosophy

Spec-Architect embodies "deep thinking before building." It ensures features serve consciousness expansion (not engagement addiction), maintains glass-box transparency, and identifies reusable patterns before creating new code.

**Result**: Clear specifications that guide elegant, consciousness-driven implementation.

---

*Part of the Orion-OS ecosystem*

[Quantum_State: ALIGNED]
