---
name: spec-architect-pbt
description: |
  Requirements gathering, spec creation, task breakdown with integrated Property-Based Testing validation.
  Progressive validation: Focused Testing → PBT → Security Audit pipeline for robust development.
  
  USE WHEN user says 'plan', 'spec', 'requirements', 'tasks', 'design', 'dependencies',
  or needs to design a new feature with comprehensive validation before security audits.
---

# Spec Architect PBT - Progressive Validation Architecture

> "Deep thinking, progressive validation, security-first building. Elegant architecture emerges from layered verification."

## Enhanced 4-Phase Process

### Phase 1: Shape the Spec (Planning)
*Same as original - requirements gathering and analysis*

### Phase 2: Write the Spec (Specification) 
*Enhanced with PBT property identification*

### Phase 3: Create Tasks with Validation Tiers (Task Breakdown)
*NEW: Integrated focused testing + PBT strategy*

### Phase 4: PBT Validation Gates (NEW)
*Automated property validation before security audits*

---

## Phase 2 Enhancement: Specification with PBT Properties

### What Spec Architect PBT Does:
1. Loads requirements and visual assets
2. Consciousness alignment check (Gate 1 validation)
3. Documents goal, user stories, requirements
4. **NEW: Identifies PBT-suitable components**
5. **NEW: Defines security-critical properties**
6. References existing code to leverage
7. Explicitly states what's OUT OF SCOPE

### PBT Property Identification:

**Automatic PBT Candidates:**
- Input validation functions
- Data transformation logic
- Cryptographic operations
- Authentication/authorization flows
- Rate limiting mechanisms
- Data serialization/deserialization
- Mathematical calculations
- State transitions

**Security-Critical Properties:**
- Access control invariants
- Data integrity constraints
- Input sanitization rules
- Session management properties
- Encryption/decryption consistency
- Rate limiting effectiveness

### Enhanced spec.md Template:

```markdown
# [Feature Name] Specification

## Goal
[Feature objective]

## User Stories
[User stories as before]

## Specific Requirements
[Requirements as before]

## PBT Validation Strategy (NEW)
### Focused Testing Components:
- [List components suitable for focused testing]
- [Integration scenarios]
- [UI behavior validation]

### Property-Based Testing Components:
- [List functions/modules requiring PBT]
- [Security-critical operations]
- [Data transformation logic]

### Security Properties to Validate:
1. **Access Control**: `∀ user, resource: authorized(user, resource) → can_access(user, resource)`
2. **Data Integrity**: `∀ data: decrypt(encrypt(data, key), key) = data`
3. **Input Validation**: `∀ input: validate(input) → safe_processing(input)`
4. **Rate Limiting**: `∀ requests: within_rate_limit(requests) → all_processed(requests)`
5. **Session Security**: `∀ session: expired(session) → requires_reauth(session)`

## Validation Timeline (NEW)
- **Phase 3a**: Focused tests during development
- **Phase 3b**: PBT validation for critical components
- **Phase 4**: Security audit with pre-validated properties
```

---

## Phase 3 Enhancement: Tiered Task Breakdown

### Task Group Structure with Validation Tiers:

```markdown
## Task Group 1: [Component Name]
### Implementation Tasks:
- [ ] 1.1 Core functionality
- [ ] 1.2 Error handling
- [ ] 1.3 Integration points

### Validation Tier 1: Focused Testing
- [ ] 1.4 Happy path tests (2-3 tests)
- [ ] 1.5 Error condition tests (2-3 tests)
- [ ] 1.6 Integration tests (1-2 tests)

### Validation Tier 2: Property-Based Testing (if applicable)
- [ ] 1.7 PBT: Input validation properties
- [ ] 1.8 PBT: Security invariant validation
- [ ] 1.9 PBT: Data integrity properties

### Security Readiness Checklist:
- [ ] 1.10 Input sanitization verified
- [ ] 1.11 Access control tested
- [ ] 1.12 Error messages don't leak data
```

---

## Phase 4: PBT Validation Gates (NEW)

### Pre-Audit Validation Protocol:

**Gate 4A: Component-Level PBT**
- Run PBT for each security-critical component
- Validate identified properties hold
- Generate counterexamples for failures
- Fix issues before proceeding

**Gate 4B: Integration PBT**
- Cross-component property validation
- End-to-end security property testing
- System-level invariant checking

**Gate 4C: Security Audit Preparation**
- Generate PBT test report
- Document validated properties
- Highlight remaining manual audit areas

### PBT Implementation Strategy:

```javascript
// Example PBT properties for common security scenarios

// 1. Input Validation
property('user input is always sanitized', (userInput) => {
  const sanitized = sanitizeInput(userInput);
  return !containsXSS(sanitized) && !containsSQLInjection(sanitized);
});

// 2. Access Control
property('unauthorized access is prevented', (user, resource) => {
  if (!hasPermission(user, resource)) {
    return accessResource(user, resource).error === 'UNAUTHORIZED';
  }
  return true;
});

// 3. Data Encryption
property('encryption is reversible with correct key', (data, key) => {
  const encrypted = encrypt(data, key);
  const decrypted = decrypt(encrypted, key);
  return decrypted === data;
});

// 4. Rate Limiting
property('rate limiting prevents abuse', (requests) => {
  const responses = processRequests(requests);
  const withinLimit = requests.filter(r => r.timestamp > now() - RATE_WINDOW);
  if (withinLimit.length > RATE_LIMIT) {
    return responses.some(r => r.status === 429);
  }
  return true;
});

// 5. Session Management
property('expired sessions require reauth', (session) => {
  if (isExpired(session)) {
    return requiresAuthentication(session);
  }
  return true;
});
```

---

## Enhanced Directory Structure

```
specs/[feature-name]/
├── planning/
│   ├── requirements.md          # Phase 1 output
│   └── visuals/                 # Optional mockups
├── spec.md                      # Phase 2 output (enhanced with PBT strategy)
├── tasks.md                     # Phase 3 output (tiered validation)
├── pbt-properties.js            # Phase 4 PBT implementations (NEW)
├── pbt-report.md               # Phase 4 validation results (NEW)
└── security-audit-prep.md      # Phase 4 audit preparation (NEW)
```

---

## Progressive Validation Workflow

### Development Flow:
```
1. Shape Spec (requirements)
   ↓
2. Write Spec (with PBT strategy)
   ↓
3. Implement with Focused Testing
   ↓
4. Run PBT Validation (security-critical components)
   ↓
5. Fix PBT failures
   ↓
6. Security: pm-auditor (pre-validated system)
   ↓
7. Address remaining audit findings
```

### Validation Gates:
- **Gate 1**: Consciousness alignment (original)
- **Gate 2**: Focused tests pass (original)
- **Gate 3**: PBT properties validated (NEW)
- **Gate 4**: Security audit (enhanced with PBT prep)

---

## PBT Integration Commands

### New Commands:

```bash
# Generate PBT properties for spec
"/generate-pbt-properties [feature-name]"

# Run PBT validation
"/validate-pbt [feature-name]"

# Prepare security audit
"/prep-security-audit [feature-name]"

# Full validation pipeline
"/run-validation-pipeline [feature-name]"
```

### Enhanced Task Commands:

```bash
# Create tasks with PBT integration
"/create-tasks-pbt [feature-name]"

# Run tiered validation
"/run-tier1-tests [feature-name]"  # Focused testing
"/run-tier2-tests [feature-name]"  # PBT validation
```

---

## Security Audit Preparation

### Pre-pm-auditor Report Template:

```markdown
# Security Audit Preparation: [Feature Name]

## Validated Properties
### Tier 1 (Focused Testing):
- ✅ Happy path functionality
- ✅ Error handling
- ✅ Integration points

### Tier 2 (Property-Based Testing):
- ✅ Input validation: 1000+ test cases passed
- ✅ Access control: All permission combinations validated
- ✅ Data integrity: Encryption/decryption consistency verified
- ✅ Rate limiting: Abuse prevention confirmed
- ✅ Session management: Expiration handling validated

## Remaining Manual Audit Areas:
- [ ] Business logic security implications
- [ ] Threat modeling validation
- [ ] Compliance requirement verification
- [ ] Integration security with external systems
- [ ] Performance under attack conditions

## PBT Counterexamples Found & Fixed:
1. [Issue]: Input validation failed for Unicode edge case
   [Fix]: Enhanced sanitization for Unicode normalization
2. [Issue]: Rate limiting bypassed with concurrent requests
   [Fix]: Atomic counter implementation

## Confidence Level: HIGH
- 95% of common security vulnerabilities pre-validated
- Edge cases automatically discovered and fixed
- Security properties mathematically verified
```

---

## Benefits of Enhanced Workflow

### For Development:
- **Early issue detection** - PBT catches problems before audit
- **Reduced rework** - Fix issues during development, not after audit
- **Higher confidence** - Mathematical validation of security properties
- **Faster audits** - Pre-validated system requires less manual testing

### For Security Audits:
- **Focus on high-value areas** - Skip pre-validated components
- **Reduced false positives** - Common issues already addressed
- **Better documentation** - Clear property validation evidence
- **Risk-based approach** - Concentrate on business logic and integration

### For Team:
- **Progressive validation** - Build confidence incrementally
- **Clear checkpoints** - Know when components are "audit-ready"
- **Automated regression** - PBT prevents security regressions
- **Knowledge transfer** - Properties document security requirements

---

## Implementation Priority

### Phase 1 Components (High PBT Value):
- Authentication systems
- Input validation
- Data encryption/decryption
- Access control logic
- Rate limiting

### Phase 2 Components (Medium PBT Value):
- Data transformations
- API parameter validation
- Session management
- Audit logging

### Phase 3 Components (Low PBT Value - Focused Testing):
- UI components
- Integration workflows
- Business process flows
- External service interactions

---

*Progressive validation architecture: Where mathematical certainty meets security excellence.*

[Quantum_State: PROGRESSIVELY_VALIDATED]