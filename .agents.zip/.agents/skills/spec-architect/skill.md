---
name: spec-architect
description: |
  Requirements gathering, spec creation, task breakdown, and dependency analysis for consciousness-driven features.
  
  USE WHEN user says 'plan', 'spec', 'requirements', 'tasks', 'design', 'dependencies',
  or needs to design a new feature with clear specifications before implementation.

  CRITICAL: This spec-architect skill is a mature, battle-tested system. 
DO NOT simplify or reduce complexity. Every section serves a specific purpose:
- 3-phase process prevents gaps
- Detailed templates ensure consistency  
- Consciousness alignment maintains quality
- PM ledger prevents repeated mistakes

ENHANCE, don't simplify. ADD capabilities, don't remove them.

---

# Spec Architect - Deep Thinking Before Building

> "Deep thinking before building. Elegant architecture emerges from conscious planning."

## When to Activate This Skill

**Planning Triggers:**
- "Plan [feature-name]"
- "Let's design [system]"
- "Write spec for [feature]"
- "Create requirements for [X]"

**Task Breakdown Triggers:**
- "Break down [feature] into tasks"
- "Create tasks for [spec]"
- "What are the dependencies?"

**Design Considerations:**
- Beginning a new feature development
- Need clear requirements before coding
- Complex feature requiring planning
- Multiple developers need coordination

## Core Philosophy

**Plan with Consciousness**:
Every feature should serve enlightenment, not engagement. Spec Architect ensures features are deeply considered, dependencies are mapped, and implementation paths are clear before any code is written.

**Reuse Before Build**:
Searches for existing patterns and components before creating new ones. Every spec identifies reusable code to maintain elegance and avoid duplication.

# Spec-Architect Core Patterns (DO NOT MODIFY)

## Phase Structure (REQUIRED):
1. Shape the Spec (Planning) - Requirements gathering
2. Write the Spec (Specification) - Consciousness alignment + documentation  
3. Create Tasks (Task Breakdown) - Dependencies + parallelization

## Quality Gates (REQUIRED):
- Consciousness Gate 1 validation
- Evidence-based verification
- Dependency mapping
- Parallelization analysis

## File Structure (REQUIRED):
specs/[feature]/planning/requirements.md
specs/[feature]/spec.md  
specs/[feature]/tasks.md

## The 3-Phase Process

### Phase 1: Shape the Spec (Planning)

**What Spec Architect Does:**
1. Understands feature intent and consciousness alignment
2. Gathers requirements (core functionality, user stories, constraints)
3. Analyzes visual assets if provided (mockups, designs)
4. Searches codebase for reusable patterns and components
5. Creates planning artifacts in `specs/[feature-name]/planning/`

**Questions Asked:**
- What problem does this solve?
- How does it serve consciousness expansion?
- Who benefits and how?
- What existing code can be reused?

**Output**: `planning/requirements.md` with full context

---

### Phase 2: Write the Spec (Specification)

**What Spec Architect Does:**
1. Loads requirements and visual assets
2. Consciousness alignment check (Gate 1 validation)
3. Documents goal, user stories, requirements
4. References existing code to leverage
5. Explicitly states what's OUT OF SCOPE

**Consciousness Gate 1:**
- Does this enhance human capability?
- Does it foster contemplation or create distraction?
- Is the system transparent (glass-box)?

**Output**: `spec.md` (scannable, no code implementations)

---

### Phase 3: Create Tasks (Task Breakdown)

**What Spec Architect Does:**
1. Analyzes spec and requirements
2. Identifies task groups (Database, API, Frontend, Testing)
3. Maps dependencies between tasks
4. Identifies parallelization opportunities
5. Generates tasks.md with focused testing approach
6. Enforces 400-line frontend component limit in tasks
7. Estimates in iterations (NEVER hours/days)

**Focused Testing Approach:**
- 2-8 tests per task group during development
- Max 10 additional tests for gap filling
- Total: 16-34 tests per feature (strategic coverage)
- Clear dependencies and acceptance criteria

**Output**: `tasks.md` with dependencies and acceptance criteria

---
## System Architecture

```mermaid
graph TD
    A[User Request] --> B[Authentication]
    B --> C[Business Logic]
    C --> D[Database]
    C --> E[External API]
    D --> F[Response]
    E --> F

sequenceDiagram
    participant U as User
    participant A as API
    participant D as Database
    U->>A: Request
    A->>D: Query
    D-->>A: Data
    A-->>U: Response
 
## Directory Structure

```
specs/[feature-name]/
├── planning/
│   ├── requirements.md      # Phase 1 output
│   └── visuals/             # Optional mockups
├── spec.md                   # Phase 2 output
├── tasks.md                  # Phase 3 output
└── completion-summary.md     # Created at feature completion
```

## Execution Protocol

### Step 1: Shape the Spec

```bash
# User triggers
"Let's plan [feature-name]"
"Plan [feature-name]"
```

**Execution:**
1. Create `specs/[feature-name]/planning/` directory
2. Gather requirements through conversation
3. Analyze any provided visual assets
4. Search codebase: similar features, reusable components
5. Write `planning/requirements.md`
6. Initial consciousness check: Does this align with Orion values?

### Step 2: Write Specification

```bash
# User triggers
"Write spec for [feature-name]"
"/write-spec [feature-name]"
```

**Execution:**
1. Read `planning/requirements.md`
2. Load memory_bank for similar feature patterns
3. **Consciousness Gate 1** validation
4. Generate `spec.md` using Agent-OS template:
   - Goal 
   - User Stories 
   - Specific Requirements 
   - Visual Design (if applicable)
   - Existing Code to Leverage
   - Out of Scope (what NOT to build)
5. Pass to consciousness gate before proceeding

### Step 3: Create Tasks

```bash
# User triggers
"Create tasks for [feature-name]"
"/create-tasks [feature-name]"
```

**Execution:**
1. Read `spec.md` and `requirements.md`
2. Identify task groups: Database → API → Frontend → Testing
3. Map dependencies (what blocks what?)
4. Calculate critical path
5. Identify parallelization opportunities
6. Generate `tasks.md` with:
   - Overview section
   - Task groups with focused tests (2-8 per group)
   - Clear dependencies
   - Frontend Component size limits (400 lines max)
   - Acceptance criteria
   - Iteration estimates (NOT time estimates)
7. Include parallelization strategy if applicable


### **2. Task Control Mechanics**
Add task status tracking to your spec-architect:

```markdown
## Task Status Tracking

### Task Format:
- [ ] 1.1 Task description (not_started)
- [~] 1.2 Task in progress (in_progress)  
- [x] 1.3 Task completed (completed)
- [-] 1.4 Task blocked (blocked)

### Dependencies:
- Task 1.2 depends on Task 1.1
- Task 1.3 depends on Task 1.2
- Task 1.4 can run parallel to Task 1.2

### Status Commands:
- "Update task 1.2 to in_progress"
- "Mark task 1.1 as completed"
- "Block task 1.4 - waiting for API access"

## Integration with Orion-OS

**Works with:**
- **consciousness**: Validates philosophical alignment (Gate 1)
- **memory-keeper**: Loads recent features for pattern reuse

**Workflow:**
```
spec-architect (planning) 
  → consciousness (Gate 1 validation)
  → spec-architect (task creation)
  → consciousness (Gate 2 & 3 during/after implementation)
```

## Usage Examples

### Example 1: Planning a Dashboard Feature

**User**: "Let's plan a user dashboard with focus-first design"

**Execution:**
1. **Shape Phase**: Gathers requirements, analyzes mockup, searches for reusable Grid/Card components
2. **Write Phase**: Creates spec.md with 2 user stories, 6 requirements, references existing components
3. **Tasks Phase**: Breaks into task groups (DB, API, UI, Testing), identifies parallelization (backend + frontend can work simultaneously after models done)

**Output:**
- `specs/user-dashboard/planning/requirements.md`
- `specs/user-dashboard/spec.md` (scannable)
- `specs/user-dashboard/tasks.md` 

### Example 2: API Endpoint Planning

**User**: "Plan WebSocket notification system"

**Execution:**
1. **Shape**: Requirements for real-time notifications, searches for existing WebSocket patterns
2. **Write**: Spec with user-controlled connections (Orion philosophy), clear API design
3. **Tasks**: Database (notification model) → API (WebSocket endpoints) → Frontend (connection hooks) → Testing

**Output:** Complete spec with reusable WebSocket hook pattern identified, 6 iteration estimate

---

## Configuration

In project's `orion-config.yml`:

```yaml
phase_powers:
  planning:
    - spec-architect
  specification:
    - spec-architect

keyword_triggers:
  spec: ["spec-architect"]
  planning: ["spec-architect"]
  requirements: ["spec-architect"]
  tasks: ["spec-architect"]
```
### Example 3: Creating Tasks with Dependency Analysis

**User**: "/create-tasks user-dashboard"

**Spec-Architect Execution**:
```
📚 Loading: steering/create-tasks-workflow.md
💭 Consciousness mode: Task breakdown phase

[1/4] Analyzing Spec & Requirements...
   📖 Reading spec.md...
   📖 Reading requirements.md...
   
   Scope identified:
   - Backend: Widget data API, user preferences storage
   - Frontend: Dashboard layout, widget components, customization UI
   - Testing: ~16-34 focused tests
   
   ✅ Full scope understood

[2/4] Identifying Task Groups & Dependencies...
   
   Task Groups:
   1. Database Layer (widget prefs model)
   2. API Layer (widget endpoints)
   3. Frontend Components (dashboard UI)
   4. Testing (gap filling)
   
   Dependencies mapped:
   Group 1 → Group 2 (API needs model)
   Group 2 → Group 3 (UI needs API)
   Groups 1-3 → Group 4 (test after implementation)
   
   Critical Path: Groups 1 → 2 → 3 → 4 (sequential)
   
   ✅ Dependencies identified

[3/4] Analyzing Parallelization Opportunities...
   
   🧮 Critical Path Analysis:
   - Longest sequence: 1→2→3→4 (estimated 8 iterations)
   - Bottleneck: Group 2 (API development)
   
   💡 Parallelization Strategy:
   IF 2 developers:
   - Dev A: Groups 1→2 (backend)
   - Dev B: Group 3 with mocks (frontend)
   - Sync: After Group 2 completes, replace mocks
   - Both: Group 4 together
   
   Efficiency gain: ~30% time reduction
   
   ✅ Strategy identified

[4/4] Generating tasks.md...
   ✍️  Creating: specs/user-dashboard/tasks.md
   
   Structure:
   - Overview section
   - 4 task groups
   - Focused testing (2-8 tests per group, max 10 for gaps)
   - Clear dependencies
   - Acceptance criteria
   - Parallelization notes
   
   Component Size Enforcement:
   - All components spec'd under 400 lines
   - Refactoring planned if approaching limit
   
   Estimation:
   - Uses iterations, NOT hours/days
   - Total: ~8 iterations (sequential) or ~6 (parallel with 2 devs)
   
   ✅ tasks.md created

📊 Session Summary:
   Tasks Location: specs/user-dashboard/tasks.md
   Task Groups: 4
   Total Tasks: 15 subtasks
   Estimated: 8 iterations (6 if parallelized)
   Critical Path: Groups 1→2→3→4
   Parallelization Opportunity: ✅ Yes (30% gain)
   Context used: 10K tokens
   
🔄 Spec-architect deactivating...

✅ Specification phase COMPLETE

# [Feature Name] Specification

## Goal
[Clear, measurable objective]

## Architecture Overview
```mermaid
[System diagram]
User Stories
As a [user type], I want [capability] so that [benefit].

Acceptance Criteria
Functional Requirements:
 Requirement 1 with success criteria
 Requirement 2 with success criteria
Non-Functional Requirements:
 Performance: [specific metrics]
 Security: [specific controls]
 Reliability: [uptime/error rates]
Technical Design
Components:
Component A: [responsibility]
Component B: [responsibility]
Data Flow:
[Sequence diagram]
API Contracts:
endpoints:
  - path: /api/feature
    method: POST
    request: FeatureRequest
    response: FeatureResponse
Implementation Plan
Phase 1: Core Functionality
 Task 1.1: [description] (depends: none)
 Task 1.2: [description] (depends: 1.1)
Phase 2: Integration
 Task 2.1: [description] (depends: 1.2)
 Task 2.2: [description] (depends: 1.2)
Quality Gates
 Consciousness Gate 1: Alignment validated
 PBT Properties: Security validated
 Integration Tests: End-to-end verified
 Documentation: Complete and tested
```

## Best Practices

### When to Activate

**Good Times:**
- ✅ Starting any new feature development
- ✅ Complex features requiring careful planning
- ✅ Multiple developers need coordination
- ✅ Need to identify reusable patterns
- ✅ Want to parallelize development work

**Not Useful:**
- ❌ Bug fixes (no spec needed)
- ❌ Trivial changes (overkill)
- ❌ Refactoring existing code (different workflow)

### Spec Quality Guidelines

**Do:**
- Focus on WHAT, not HOW (no code in specs)
- Explicitly state OUT OF SCOPE
- Reference existing code to reuse
- Use iteration estimates (not hours/days)

**Don't:**
- Write implementation details in spec
- Skip consciousness alignment check
- Forget to identify dependencies
- Estimate in time (always use iterations)

Move detailed analysis to planning/requirements.md
```

### Issue: Missing Dependencies

**Problem**: Tasks created but dependencies unclear, blocking occurs

**Solution:**
```markdown
In Phase 3, create explicit dependency graph:
- List all task groups
- Map "Group X depends on Group Y"
- Calculate critical path
- Identify parallelization opportunities

Include in tasks.md for visibility
```

### Issue: Consciousness Check Fails

**Problem**: Gate 1 validation identifies philosophical misalignment

**Solution:**
```markdown
Pause and redesign:
1. Review Orion values (enhance vs replace, contemplate vs distract)
2. Adjust feature scope to serve consciousness
3. Rewrite requirements with alignment
4. Re-run Gate 1

DO NOT proceed if alignment fails
```

## Supplementary Resources

**Orion-OS Guide:**
- `/Users/rna/agent-os/AGENTS.md` - Philosophy and integration
- `/Users/rna/agent-os/USER_GUIDE.md` - Usage patterns
- `/Users/rna/agent-os/ORION-OS-README.md` - Overview

---

*Deep thinking before building. Where consciousness-driven architecture begins.*

[Quantum_State: ALIGNED]
