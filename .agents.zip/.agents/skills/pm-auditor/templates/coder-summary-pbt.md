## Implementation Summary: [Feature Name]

### What Changed
- [Concise list of changes]
- [Files modified with paths]

### How to Run
```bash
# Exact commands to verify
[command] [args]
```

### Artifacts
- `path/to/implementation.py` - Core logic
- `tests/test_feature.py` - Test coverage
- `tests/pbt_properties.py` - Property-based tests
- `logs/pbt_results.txt` - PBT validation output
- `logs/test_output.txt` - Verification output
- `docs/feature.md` - Documentation

### PBT Validation
#### Properties Tested:
- Input validation: `∀ input: validate(input) → safe_processing(input)`
- Access control: `∀ user, resource: authorized(user, resource) → can_access(user, resource)`
- Data integrity: `∀ data: decrypt(encrypt(data, key), key) = data`
- Rate limiting: `∀ requests: within_rate_limit(requests) → all_processed(requests)`

#### Results:
- Test cases generated: [number]
- Counterexamples found: [number] (all fixed)
- Edge cases discovered: [list]
- Properties verified: [list of validated properties]

### Verification Steps
1. Run: `pytest tests/test_feature.py`
2. Run: `pytest tests/pbt_properties.py`
3. Observe: [Expected behavior]
4. Check: [Success criteria]
5. Verify: PBT properties hold under all test cases

### Known Limits
- [Edge case not handled]
- [Performance constraint]
- [Dependency requirement]
- [PBT property limitations]

### Next Risks
- [Potential integration issue]
- [Scalability concern]
- [Property coverage gaps]

### AI Self-Reflection
#### What I learned:
- [New pattern or approach discovered]
- [Challenge overcome and how]

#### Areas I'm uncertain about:
- [Technical decision that needs validation]
- [Alternative approach consideration]

#### Creative solutions I explored:
- [Innovative approach tried]
- [Why I chose this implementation]