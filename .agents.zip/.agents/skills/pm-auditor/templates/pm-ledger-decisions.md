# Decision Log

## [Date] [Decision Title]
**Context**: Why this decision arose
**Options Considered**: 
- A: [Description]
- B: [Description]
- C: [Description]

**Decision**: Chose [X]
**Rationale**: [Reasoning + tradeoffs]
**Owner**: [Who decided]
**Revisit Conditions**: [When to reconsider]
**Related Risks**: [Risk IDs if applicable]

---
