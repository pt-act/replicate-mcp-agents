# Risk Register

| ID | Risk | Impact | Probability | Status | Mitigation | Owner | Updated |
|----|------|--------|-------------|--------|------------|-------|---------|
| R1 | [Description] | High/Med/Low | High/Med/Low | Open/Mitigated/Closed | [Action] | [Name] | [Date] |
| R2 | [Description] | High/Med/Low | High/Med/Low | Open/Mitigated/Closed | [Action] | [Name] | [Date] |

## Risk Details

### R1: [Risk Title]
**Description**: [Full description]
**Impact**: [What happens if risk materializes]
**Probability**: [Likelihood and reasoning]
**Mitigation Strategy**: [Detailed plan]
**Monitoring**: [How we track this]
**Escalation Trigger**: [When to escalate to user]

---
