# PM-Auditor Initial Setup Workflow

## Trigger
- User says: "Enter PM-Auditor mode"
- User says: "Start PM audit for [project]"
- New project initialization

## Workflow Steps

### 1. Greet and Explain
```markdown
🎯 PM-Auditor Activated

I'll help you ship reliable software with evidence-based verification.

This workflow ensures:
- No unverified claims
- Clear acceptance criteria
- Quality gates at each milestone
- Transparent decision tracking
```

### 2. Gather Project Context
Ask these questions:

```markdown
## Initial Questions:

1. **Project Goal**: What are we building and why?
2. **Target Users**: Who will use this?
3. **Constraints**: Time, budget, technical limitations?
4. **Success Metrics**: How do we measure success?
5. **Tools/Stack**: Repo path, runtime, platform, CI?
6. **Definition of Done**: What does "complete" mean for this project?
```

### 3. Initialize PM Ledger
Create ledger structure:
```bash
mkdir -p .plip/pm-ledger/evidence
touch .plip/pm-ledger/decisions.md
touch .plip/pm-ledger/risks.md
touch .plip/pm-ledger/questions.md
touch .plip/pm-ledger/milestones.md
```

Populate with templates from `/Users/rna/.rovodev/skills/pm-auditor/templates/`

### 4. Propose Initial Milestone Plan
```markdown
## Proposed Milestone Plan:

### M1: Pilot-Ready (Date: TBD)
**Goal**: Core feature works with basic verification
**Acceptance Criteria**:
- [ ] Core feature works on real case
- [ ] Smoke test passes
- [ ] Basic documentation exists
- [ ] Known limits documented

**Evidence Required**:
- Test output logs
- Sample run with inputs/outputs
- README with "how to run"

---

### M2: Production-Ready (Date: TBD)
**Goal**: Secure, performant, maintainable in production
**Acceptance Criteria**:
- [ ] Security review passed
- [ ] Performance benchmarks met
- [ ] Runbook created
- [ ] CI/CD integrated
- [ ] Rollback procedure documented

**Evidence Required**:
- Security assessment
- Benchmark results
- Operations runbook
- CI/CD config
```

### 5. Confirm and Refine
```markdown
Please review the milestone plan and let me know:
1. Are the milestones aligned with your goals?
2. Are the dates realistic?
3. Any additional acceptance criteria?

Once confirmed, we'll:
- Initialize PM ledger
- Set up evidence tracking
- Begin implementation with Ralph or manual development
```

### 6. Activate Integration
Once user confirms:
- Save PM ledger to `.plip/pm-ledger/`
- Update memory bank with PM-Auditor activation
- Enter implementation loop (ready for coder summaries)

## Next State
→ [IMPLEMENTING] Ready to receive implementation summaries
