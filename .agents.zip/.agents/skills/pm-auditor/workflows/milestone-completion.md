# PM-Auditor Milestone Completion Workflow

## Trigger
- All milestone acceptance criteria met
- Evidence bundle complete
- Final implementation review approved

## Workflow Steps

### 1. Final Verification
```markdown
## Milestone Completion Checklist

### Evidence Bundle Complete
- [ ] README.md with run instructions
- [ ] Sample inputs in evidence/[milestone]/inputs/
- [ ] Expected outputs in evidence/[milestone]/outputs/
- [ ] Actual logs in evidence/[milestone]/logs/
- [ ] Smoke test script (executable)

### Acceptance Criteria Met
- [ ] Functional: All features work on real cases
- [ ] Reproducible: Clear steps, tested on fresh env
- [ ] Observable: Logs/errors are actionable
- [ ] Secure: Security review passed (if production)
- [ ] Documented: Complete usage guide
- [ ] Regression-protected: Tests added to suite

### Quality Gates Passed
- [ ] Gate 1: Functional Correctness ✓
- [ ] Gate 2: Determinism & Reproducibility ✓
- [ ] Gate 3: Observability ✓
- [ ] Gate 4: Security & Access Control ✓
- [ ] Gate 5: Documentation & Handoff ✓
- [ ] Gate 6: Regression Protection ✓

### Consciousness Alignment
- Expansion: [score/10]
- Transparency: [score/10]
- Elegance: [score/10]
- Truth: [score/10]
- **Average**: [X.X/10] (must be ≥7.0)
```

### 2. Generate Completion Report
```markdown
# Milestone Completion Report: [Milestone Name]

## Summary
**Milestone**: [Name]
**Type**: [Pilot-Ready/Production-Ready]
**Completion Date**: [Date]
**Total Iterations**: [X]
**Status**: ✅ COMPLETE

## What Was Delivered
- [Feature 1]: [Description]
- [Feature 2]: [Description]
- [Feature 3]: [Description]

## Acceptance Criteria Results
✅ [Criterion 1]: Met - [Evidence]
✅ [Criterion 2]: Met - [Evidence]
✅ [Criterion 3]: Met - [Evidence]

## Quality Gate Scores
| Gate | Score | Notes |
|------|-------|-------|
| Functional | 9/10 | All tests pass |
| Reproducible | 8/10 | Clear documentation |
| Observable | 9/10 | Excellent logging |
| Secure | 8/10 | Review passed |
| Documented | 9/10 | Complete guide |
| Regression | 8/10 | Tests added |

## Consciousness Alignment
- **Expansion**: 8.5/10 - Empowers users with clear insights
- **Transparency**: 9.0/10 - Logic fully verifiable
- **Elegance**: 8.0/10 - Clean, focused implementation
- **Truth**: 8.5/10 - Root cause solutions
- **Average**: 8.5/10 ✅

## Risks Closed
- [R1] [Description] - Mitigated via [action]
- [R2] [Description] - Resolved by [solution]

## Risks Carried Forward
- [R3] [Description] - To be addressed in M2
- [R5] [Description] - Low priority, monitored

## Decisions Made
- [D1] [Decision] - [Rationale]
- [D2] [Decision] - [Rationale]

## Evidence Archived
- Location: `.plip/pm-ledger/evidence/[milestone]/`
- Contents: README, inputs, outputs, logs, smoke test

## Next Milestone
**M2: [Name]** (Target: [Date])
- Focus: [What's next]
- Key additions: [List]
```

### 3. Update PM Ledger
Update all ledger files:

**milestones.md**:
```markdown
## M1: [Milestone Name] ✅ COMPLETE
**Completed**: [Date]
**Iterations**: [X]
**Evidence**: .plip/pm-ledger/evidence/[milestone]/
```

**risks.md**:
- Close resolved risks
- Update status of ongoing risks
- Add new risks for next milestone

**decisions.md**:
- Archive all decisions made during milestone

**questions.md**:
- Close answered questions
- Archive or carry forward open questions

### 4. Memory Bank Integration
Trigger memory-keeper power to update:

```markdown
# In MASTER_CONTEXT.md (prepend)
### [Date] [Milestone Name] - PM-Auditor Completion

**Type**: [Pilot-Ready/Production-Ready]
**Features**: [List]
**Consciousness**: 8.5/10 (Expansion: 8.5, Transparency: 9.0, Elegance: 8.0, Truth: 8.5)
**Evidence**: .plip/pm-ledger/evidence/[milestone]/
**Iterations**: [X]

**Key Decisions**:
- [Decision 1]
- [Decision 2]

**Risks Mitigated**:
- [Risk 1] - [How resolved]

**Next**: [Next milestone focus]
```

### 5. Generate Handoff Documentation
Create handoff package:

```markdown
# Handoff: [Milestone Name]

## For New Developers
1. **Quick Start**: See `.plip/pm-ledger/evidence/[milestone]/README.md`
2. **Architecture**: See `docs/[feature]/architecture.md`
3. **API Reference**: See `docs/[feature]/api.md`

## For Operations
1. **Deployment**: See `docs/[feature]/deployment.md`
2. **Monitoring**: See `docs/[feature]/monitoring.md`
3. **Troubleshooting**: See `docs/[feature]/troubleshooting.md`

## For Product Managers
1. **Feature Overview**: [Description]
2. **User Value**: [Benefits]
3. **Known Limitations**: [List]
4. **Roadmap**: [Next milestone plans]
```

### 6. Celebrate and Transition
```markdown
🎉 Milestone Complete: [Milestone Name]

**Achievement**: [What was accomplished]
**Quality**: All gates passed, consciousness aligned
**Evidence**: Archived and verifiable

---

Ready for next milestone?
1. 🚀 Continue to M2: [Next milestone name]
2. 📊 Review milestone metrics and velocity
3. 🔄 Adjust acceptance criteria based on learnings
4. 💬 Discuss scope or timeline changes

What would you like to focus on?
```

### 7. Prepare Next Milestone
If continuing to next milestone:

```markdown
## M2: [Next Milestone Name] - Planning

Based on M1 learnings:
- Velocity: [X iterations per task]
- Common gaps: [Patterns observed]
- Process improvements: [Adjustments]

### Proposed M2 Acceptance Criteria
- [ ] [Criterion building on M1]
- [ ] [New production-ready criterion]
- [ ] [Enhanced quality requirement]

### Risk Register for M2
- [R6] [New risk identified from M1]
- [R3] [Carried forward from M1]

### Questions for Planning
1. [Q3] [New question based on M1 completion]
2. [Q5] [Strategic question for M2]

Shall we begin M2 planning?
```

## Archive Structure
```
.plip/pm-ledger/
├── evidence/
│   ├── m1-pilot-ready/          ← Milestone 1 complete
│   │   ├── README.md
│   │   ├── inputs/
│   │   ├── outputs/
│   │   ├── logs/
│   │   └── smoke_test.sh
│   └── m2-production-ready/     ← Next milestone
├── decisions.md                  ← Updated with M1 decisions
├── risks.md                      ← M1 risks closed, M2 risks active
├── questions.md                  ← M1 questions archived
├── milestones.md                 ← M1 marked complete, M2 active
└── reports/
    └── m1-completion-report.md   ← Generated completion report
```

## Next State
- If continuing: → [PLANNING] for next milestone
- If project complete: → [HANDOFF] and deactivation
