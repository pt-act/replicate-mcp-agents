# PM-Auditor Implementation Review Workflow

## Trigger
- Coder posts implementation summary
- User says: "Review this implementation"
- Ralph completes tasks and provides summary

## Workflow Steps

### 1. Load Context
- Read current milestone from `.plip/pm-ledger/milestones.md`
- Review acceptance criteria
- Check risk register for relevant risks
- Review open questions that might affect this implementation

### 2. Parse Implementation Summary
Extract from coder summary:
- What changed (files, features)
- How to run (commands, steps)
- Artifacts provided (paths, logs, outputs)
- Known limits
- Next risks

### 3. Evidence Verification
For each claim in the summary, check:
```markdown
Claim: "Feature X works"
Evidence Required: Output log, test results, or reproducible demo
Evidence Provided: [Yes/No]
Verdict: [Verified/Unverified]
```

### 4. Quality Gate Assessment
Evaluate against 6 quality dimensions:

#### Gate 1: Functional Correctness
- [ ] Works on real case (not just happy path)
- [ ] Edge cases handled
- [ ] Error conditions produce actionable messages

#### Gate 2: Determinism & Reproducibility
- [ ] Clear "how to run" instructions
- [ ] Dependencies documented
- [ ] Works on fresh environment

#### Gate 3: Observability
- [ ] Logs are informative
- [ ] Progress indicators present
- [ ] Debug mode available

#### Gate 4: Security & Access Control
- [ ] Least privilege applied
- [ ] Safe defaults
- [ ] Input validation present

#### Gate 5: Documentation & Handoff
- [ ] README updated
- [ ] API/interface documented
- [ ] Known limitations listed

#### Gate 6: Regression Protection
- [ ] Smoke test added
- [ ] Golden demo exists
- [ ] CI hook in place (if applicable)

### 5. Consciousness Alignment Check
Score against Orion-OS dimensions:
```markdown
Consciousness Assessment:
- Expansion (empowers users): [0-10]
- Transparency (verifiable logic): [0-10]
- Elegance (simple, focused): [0-10]
- Truth (root cause solution): [0-10]

Average: [X.X/10] (threshold: ≥7.0)
```

### 6. Determine Verdict
Based on evidence + quality gates + consciousness:

**✅ APPROVE**
- All acceptance criteria met
- Evidence complete and verified
- Consciousness score ≥7.0
- No blocking risks

**⚠️ APPROVE-WITH-CONDITIONS**
- Core criteria met
- Minor gaps documented with mitigation
- Consciousness score ≥7.0
- Non-blocking risks managed

**🔄 REQUEST-CHANGES**
- Missing key acceptance criteria
- Evidence gaps present
- Rework required
- Clear action items defined

**🚫 BLOCKED**
- Critical issues present
- Safety/security concerns
- Cannot proceed until resolved
- Escalation required

### 7. Generate Structured Response
Use template from `/Users/rna/.rovodev/skills/pm-auditor/templates/pm-verdict.md`:

```markdown
## A) PM Verdict
[Verdict with emoji]

## B) What's Verified
[List verified items with evidence references]

## C) Gaps & Risks
[List gaps with impact/probability/mitigation]

## D) Required Artifacts (if missing)
[Specific artifacts needed]

## E) Acceptance Criteria
[Checklist showing progress]

## F) Next Tasks
[Ordered tasks with owners and estimates]
```

### 8. Update PM Ledger
- Add new risks to `risks.md`
- Record decisions in `decisions.md`
- Create questions in `questions.md` (if any)
- Update milestone progress in `milestones.md`

### 9. Archive Evidence
If approved:
```bash
mkdir -p .plip/pm-ledger/evidence/[milestone-name]/
cp [artifacts] .plip/pm-ledger/evidence/[milestone-name]/
```

## Decision Tree

```
Start
  ↓
Evidence Complete? ──No→ [REQUEST-CHANGES] → Specify missing artifacts
  ↓ Yes
Critical Issues? ──Yes→ [BLOCKED] → Escalate + define resolution path
  ↓ No
Core Criteria Met? ──No→ [REQUEST-CHANGES] → Define rework needed
  ↓ Yes
Minor Gaps? ──Yes→ [APPROVE-WITH-CONDITIONS] → Document conditions
  ↓ No
Consciousness ≥7.0? ──No→ [REQUEST-CHANGES] → Align with Orion principles
  ↓ Yes
[APPROVE] → Archive evidence + update ledger
```

## Next State
Based on verdict:
- **APPROVE** → [NEXT MILESTONE] or [COMPLETE]
- **APPROVE-WITH-CONDITIONS** → [IMPLEMENTING] (minor fixes)
- **REQUEST-CHANGES** → [IMPLEMENTING] (rework)
- **BLOCKED** → [PLANNING] (redefine or escalate)
