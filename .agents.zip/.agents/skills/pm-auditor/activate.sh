#!/bin/bash
# PM-Auditor Activation Script
# Creates PM ledger structure for a project

set -e

PROJECT_DIR=${1:-.}
LEDGER_DIR="$PROJECT_DIR/.plip/pm-ledger"

echo "🎯 Initializing PM-Auditor for project: $PROJECT_DIR"

# Create ledger directory structure
mkdir -p "$LEDGER_DIR/evidence"
mkdir -p "$LEDGER_DIR/reports"

# Copy templates if they don't exist
TEMPLATE_DIR="/Users/rna/.rovodev/skills/pm-auditor/templates"

if [ ! -f "$LEDGER_DIR/decisions.md" ]; then
    cp "$TEMPLATE_DIR/pm-ledger-decisions.md" "$LEDGER_DIR/decisions.md"
    echo "✓ Created decisions.md"
fi

if [ ! -f "$LEDGER_DIR/risks.md" ]; then
    cp "$TEMPLATE_DIR/pm-ledger-risks.md" "$LEDGER_DIR/risks.md"
    echo "✓ Created risks.md"
fi

if [ ! -f "$LEDGER_DIR/questions.md" ]; then
    cp "$TEMPLATE_DIR/pm-ledger-questions.md" "$LEDGER_DIR/questions.md"
    echo "✓ Created questions.md"
fi

if [ ! -f "$LEDGER_DIR/milestones.md" ]; then
    cp "$TEMPLATE_DIR/pm-ledger-milestones.md" "$LEDGER_DIR/milestones.md"
    echo "✓ Created milestones.md"
fi

echo ""
echo "✅ PM-Auditor ledger initialized at: $LEDGER_DIR"
echo ""
echo "Next steps:"
echo "1. Define project goals and milestones"
echo "2. Set acceptance criteria in milestones.md"
echo "3. Begin implementation with evidence tracking"
echo ""
echo "Use 'Enter PM-Auditor mode' to activate in RovoDev"
