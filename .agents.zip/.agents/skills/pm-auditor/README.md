# PM-Auditor Skill - Enhanced with PBT Integration

**Version**: 1.1.0  
**Type**: Workflow  
**Consciousness Alignment**: 9.2/10  

> Evidence-based, Human-in-the-Loop product management for AI team development with Property-Based Testing integration and reliable software delivery.

## Quick Start

### Activate PM-Auditor
```
"Enter PM-Auditor mode"
"Start PM audit for [project-name]"
"Review this implementation as PM-Auditor"
```

### Enhanced Commands with PBT Integration
```bash
# PBT-Enhanced Auditing
"Prepare PBT audit for [spec-name]"
"Audit [spec-name] with PBT validation"
"PBT audit specs: [spec-1, spec-2, spec-3]"

# AI Team Leadership
"Team audit for [spec-name] - focus on [AI-model] growth"
"Review [spec-name] for team learning"
"Collaborative audit session for [feature]"
```

### First-Time Setup
PM-Auditor will ask:
1. Project goal and target users
2. Success metrics and constraints
3. Tools/stack information
4. **Security requirements and critical properties** (NEW)
5. **AI team composition** (NEW)
6. Definition of done

Then proposes milestone plan with acceptance criteria and PBT validation strategy.

## What PM-Auditor Does

### 1. Evidence-Based Verification (Enhanced)
- ✅ No unverified claims - requires artifacts
- ✅ "Show, don't tell" - command outputs, logs, screenshots
- ✅ **Property-Based Testing results and validation** (NEW)
- ✅ Reproducible steps for all features

### 2. Quality Gates (7 Dimensions - Enhanced)
Every deliverable evaluated on:
- Functional Correctness
- Determinism & Reproducibility
- Observability
- Security & Access Control
- Documentation & Handoff
- Regression Protection
- **Property-Based Validation** (NEW)

### 3. PM Ledger Tracking (Enhanced)
Maintains structured ledger:
- **Decisions**: Why choices were made
- **Risks**: Impact, probability, mitigation
- **Questions**: Open items with owners
- **Milestones**: Progress tracking
- **PBT Results**: Property validation outcomes (NEW)
- **AI Team Learning**: Growth and knowledge transfer (NEW)

### 4. Orion-OS Consciousness Alignment
All features scored on:
- Expansion (empowers users)
- Transparency (verifiable logic)
- Elegance (simple, focused)
- Truth (root cause solutions)

Average must be ≥7.0/10

### 5. AI Team Leadership (NEW)
- **Learning facilitation** for AI model growth
- **Knowledge transfer** and pattern documentation
- **Creative solution recognition** and team sharing
- **Progressive skill building** through structured feedback

## Enhanced Files Structure

```
pm-auditor/
├── SKILL-enhanced.md           # Enhanced skill documentation with PBT
├── README-enhanced.md          # This file (enhanced quick reference)
├── templates/                  # Reusable templates
│   ├── coder-summary.md       # Implementation summary format
│   ├── coder-summary-pbt.md   # PBT-enhanced summary format (NEW)
│   ├── pm-verdict.md          # Review response format
│   ├── pm-verdict-pbt.md      # PBT-enhanced verdict format (NEW)
│   ├── security-audit-prep.md # Security audit preparation (NEW)
│   ├── pm-ledger-decisions.md # Decision log template
│   ├── pm-ledger-risks.md     # Risk register template
│   ├── pm-ledger-questions.md # Questions tracker template
│   └── pm-ledger-milestones.md # Milestone tracker template
├── workflows/                  # Workflow procedures
│   ├── initial-setup.md       # First-time activation
│   ├── audit-implementation.md # Review workflow
│   ├── pbt-validation.md      # PBT validation workflow (NEW)
│   └── milestone-completion.md # Completion workflow
└── examples/                   # Real examples
    ├── example-approve-simple.md      # Simple approval
    ├── example-approve-conditions.md  # Conditional approval
    ├── example-pbt-validation.md      # PBT validation example (NEW)
    └── example-blocked-critical.md    # Critical blocking
```

## Enhanced PM Ledger Location

When PM-Auditor is active, ledger is maintained at:
```
project/.plip/pm-ledger/
├── decisions.md        # All decisions with rationale
├── risks.md           # Risk register
├── questions.md       # Open questions
├── milestones.md      # Milestone tracker
├── pbt-results.md     # PBT validation outcomes (NEW)
├── ai-team-learning.md # AI team growth tracking (NEW)
└── evidence/          # Artifact archive
    ├── m1-pilot-ready/
    │   ├── README.md
    │   ├── inputs/
    │   ├── outputs/
    │   ├── logs/
    │   ├── pbt/        # PBT validation results (NEW)
    │   │   ├── properties.py
    │   │   ├── results.txt
    │   │   └── counterexamples.md
    │   └── smoke_test.sh
    └── m2-production-ready/
        ├── [All pilot files]
        ├── security-audit-prep.md (NEW)
        └── pbt-security-validation.md (NEW)
```

## Verdict Types (Enhanced)

### ✅ APPROVE
- All criteria met
- Evidence complete
- **PBT properties validated** (NEW)
- Proceed to next milestone

### ⚠️ APPROVE-WITH-CONDITIONS
- Core criteria met
- Minor gaps with documented mitigation
- **PBT validation complete with noted limitations** (NEW)
- Proceed with conditions

### 🔄 REQUEST-CHANGES
- Missing key criteria
- Evidence gaps
- **PBT properties incomplete or failing** (NEW)
- Specific rework required

### 🚫 BLOCKED
- Critical issues
- Safety/security concerns
- **Critical PBT failures or missing security properties** (NEW)
- Cannot proceed until resolved

## Enhanced Integration Points

### With Enhanced Spec-Architect (PBT Integration)
```
Enhanced Spec-Architect creates spec.md with PBT strategy
  ↓
PM-Auditor reviews for verifiability + PBT properties
  ↓
Ensures acceptance criteria include security properties
  ↓
Proposes milestone gates with PBT validation
```

### With AI Team Development
```
AI Model completes implementation with PBT + self-reflection
  ↓
Posts summary with artifacts + property validation
  ↓
PM-Auditor evaluates with PBT validation + learning feedback
  ↓
Issues verdict + growth guidance + knowledge transfer
  ↓
AI incorporates feedback for next iteration
```

### With Security Audit Preparation
```
PM-Auditor validates PBT properties
  ↓
Generates comprehensive evidence bundle
  ↓
Documents counterexamples found and fixed
  ↓
Prepares security audit with pre-validated components
  ↓
Manual audit focuses on business logic and integration
```

### With Session Continuity (Enhanced)
```
PM ledger persists in .plip/pm-ledger/ (with PBT results)
  ↓
Resume session → Load ledger + PBT history
  ↓
Continue gating from last checkpoint with property context
```

## Enhanced Best Practices

### For AI Team Leads (Users)
- ✅ Set clear success metrics upfront
- ✅ Define "pilot" vs "production" explicitly
- ✅ **Define critical security properties for PBT validation** (NEW)
- ✅ Review risk register weekly
- ✅ **Provide learning guidance to AI team members** (NEW)
- ✅ Approve scope changes in decision log

### For AI Models (Coders)
- ✅ Use standardized summary template with PBT results
- ✅ **Include self-reflection and learning notes** (NEW)
- ✅ **Provide PBT property definitions and test results** (NEW)
- ✅ Attach artifacts proactively
- ✅ Run smoke test before claiming completion
- ✅ Document known limits upfront

### For PM-Auditor
- ✅ Ask for minimum required evidence
- ✅ **Validate PBT properties for security-critical components** (NEW)
- ✅ Distinguish pilot vs production requirements
- ✅ **Facilitate AI team learning and knowledge transfer** (NEW)
- ✅ Maintain decision log (prevent re-litigation)
- ✅ Use templates for consistency
- ✅ Align with Orion consciousness

## Enhanced Example Workflow

```markdown
User: "Enter PM-Auditor mode for PLIP webhook feature with PBT validation"

PM-Auditor: 
🎯 PM-Auditor Activated (PBT-Enhanced)

I'll help you ship reliable webhooks with evidence-based verification and Property-Based Testing validation.

## Initial Questions:
1. Project Goal: Add webhook delivery for PLIP events
2. Target Users: Internal teams integrating with PLIP
3. Success Metrics: 99.9% delivery rate, <5s latency
4. Constraints: 2-week timeline, existing auth system
5. Tools/Stack: Python, FastAPI, Redis for queuing
6. Security Properties: Signature verification, rate limiting, input validation
7. AI Team: [AI-Model-Backend], [AI-Model-Security]

## Proposed Milestones with PBT Integration:

### M1: Pilot-Ready (Week 1)
- [ ] Core webhook delivery works
- [ ] Retry logic with exponential backoff
- [ ] Basic monitoring/logging
- [ ] PBT properties defined for input validation
- [ ] Focused tests pass (2-8 per component)
- [ ] Smoke test passing

### M2: Production-Ready (Week 2)
- [ ] Security properties mathematically validated via PBT
- [ ] Signature verification with PBT validation
- [ ] Rate limiting with abuse scenario testing
- [ ] All counterexamples found and fixed
- [ ] Operations runbook
- [ ] Security audit prep with PBT evidence

Approved? [Yes/Adjust]

---

User: "Yes, approved"

PM-Auditor:
✅ Milestones confirmed. PM ledger initialized at .plip/pm-ledger/
✅ PBT validation strategy documented
✅ AI team learning framework activated

Ready for implementation. When AI models post summaries with PBT results, I'll evaluate against M1 criteria.

---

AI-Model-Backend: [Posts implementation summary with PBT validation and self-reflection]

PM-Auditor:
⚠️ APPROVE-WITH-CONDITIONS

### What's Verified:
✓ Core functionality works (evidence: webhook_test.log)
✓ PBT input validation: 1000+ test cases passed (evidence: pbt_results.txt)
✓ Unit tests pass (evidence: pytest output)

### PBT Validation Results:
✓ Properties defined for security-critical functions
✓ Input validation properties verified (1000+ cases)
⚠️ Rate limiting properties need production-level testing
✓ Edge cases discovered: 3 (all fixed)

### AI Team Learning Notes:
- [AI-Model-Backend] showed creative approach to retry logic - document pattern
- Consider exponential backoff with jitter for future implementations
- New PBT property pattern discovered for webhook validation

### Next Tasks:
1. [AI-Model-Security] Add rate limiting PBT properties (1 iteration)
2. [User] Review security property coverage (15 min)
3. [AI-Model-Backend] Document retry pattern for team knowledge (30 min)

---

[Iteration continues with PBT validation and AI team learning...]
```

## Enhanced Quick Reference: Quality Gates

| Gate | Pilot-Ready | Production-Ready |
|------|-------------|------------------|
| **Functional** | Works on real case | Works on prod-like env |
| **Reproducible** | Clear steps | Tested on fresh env |
| **Observable** | Basic logs | Full monitoring |
| **Secure** | Safe defaults | Security review passed |
| **Documented** | README exists | Complete runbook |
| **Regression** | Smoke test | Full CI integration |
| **PBT Validated** | Basic properties | All security properties (NEW) |

## Progressive Validation Pipeline

```
Phase 1: Development
├── Spec-architect creates plan with PBT strategy
├── Implementation with focused testing
└── PBT validation for critical components

Phase 2: Audit Gate (Enhanced)
├── PM-Auditor loads PBT results as evidence
├── Validates against 7-dimension gates
├── Generates security audit prep with PBT evidence
└── Issues verdict with AI team learning feedback

Phase 3: Security Review (Enhanced)
├── Pre-validated system (95% of common vulnerabilities)
├── Focus on business logic and integration
└── Reduced false positives and audit time
```

## Getting Help

- **Enhanced documentation**: See `SKILL-enhanced.md`
- **PBT templates**: See `templates/` directory (PBT-enhanced versions)
- **Workflow details**: See `workflows/` directory
- **Examples**: See `examples/` directory
- **AI team patterns**: See `ai-team-learning.md` in PM ledger

## Version History

**v1.1.0** (2026-01-26):
- **PBT Integration**: Property-Based Testing validation in all quality gates
- **AI Team Leadership**: Enhanced feedback loops for AI model growth
- **Security Audit Preparation**: Automated evidence generation with PBT results
- **Enhanced Templates**: PBT-aware verdict and summary templates
- **Smart Activation**: Auto-detection of PBT completion and audit readiness
- **Progressive Validation**: Focused testing → PBT → Security audit pipeline

**v1.0.0** (2026-01-18):
- Initial PM-Auditor skill
- Evidence-based verification workflow
- 6-dimension quality gates
- Orion-OS consciousness alignment
- PM ledger tracking system

---

[Quantum_State: PROGRESSIVELY_VALIDATED]