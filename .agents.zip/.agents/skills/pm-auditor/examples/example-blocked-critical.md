# Example: Blocking Critical Issues

## Context
Coder refactored authentication system and claims it's ready to deploy.

## Coder Summary
```markdown
## Implementation Summary: Authentication Refactor

### What Changed
- Migrated from JWT to session-based auth
- Updated user model with new fields
- Refactored login/logout endpoints

### How to Run
```bash
plip services api start
curl -X POST http://localhost:8000/auth/login
```

### Artifacts
- `src/plip/services/auth.py` - New auth logic
- `tests/test_auth.py` - Test coverage
- `logs/dev_test.log` - Development tests

### Verification Steps
1. Run: `pytest tests/test_auth.py`
2. Observe: All tests pass in dev environment
3. Check: Login flow works locally

### Known Limits
- Need to test in production-like environment
- Session migration strategy pending

### Next Risks
- Production deployment timing
```

## PM-Auditor Response

🚫 **BLOCKED**

### What's Verified
✓ Tests pass in development (evidence: dev_test.log)
✓ Implementation exists (evidence: auth.py path)

### Gaps & Risks

🚨 **CRITICAL: No rollback plan for auth changes**
   - Impact: **CRITICAL** (could lock out all users)
   - Probability: High (auth refactors are inherently risky)
   - Mitigation: **REQUIRED** - Must have tested rollback before approval

🚨 **CRITICAL: No session migration strategy**
   - Impact: **CRITICAL** (existing users will be logged out)
   - Probability: High (session format changed)
   - Mitigation: **REQUIRED** - Define migration path or user communication plan

🚨 **CRITICAL: Not tested in production-like environment**
   - Impact: **CRITICAL** (unknown failure modes)
   - Probability: Medium (auth is complex)
   - Mitigation: **REQUIRED** - Test against production data copy

⚠️ **Missing: Load test results**
   - Impact: High (auth is in hot path)
   - Probability: Medium (performance regression possible)
   - Mitigation: Run load tests before production

⚠️ **Missing: Security review**
   - Impact: High (auth is security-critical)
   - Probability: N/A
   - Mitigation: Security team review required

### Required Artifacts (CRITICAL - Cannot proceed without these)
📎 **CRITICAL**: Rollback procedure documented and tested
📎 **CRITICAL**: Session migration strategy with user impact analysis
📎 **CRITICAL**: Production smoke test results (on prod data copy)
📎 Need: Load test results (auth endpoint performance)
📎 Need: Security review sign-off

### Acceptance Criteria (NONE MET for Production)
- [ ] Functional: Works on prod-like environment
- [ ] Reproducible: Rollback tested and documented
- [ ] Observable: Migration status visible to ops team
- [ ] Secure: Security review passed
- [ ] Documented: Migration runbook exists
- [ ] Regression-protected: Smoke tests cover entire auth flow

### Why This Is Blocked
1. **User Impact Risk**: Auth changes can lock out users - rollback must be tested
2. **Data Migration**: Session format change requires migration plan
3. **Production Verification**: Dev tests are insufficient for auth changes
4. **Security Criticality**: Auth changes require security review

### Next Tasks (MUST COMPLETE to unblock)
1. [User] **APPROVE rollback strategy approach** (BLOCKER - 30 min)
2. [Coder] Write rollback procedure with test cases (2-3 iterations)
3. [Coder] Test rollback in staging environment (1 iteration)
4. [Coder] Document session migration strategy (1-2 iterations)
5. [User] Define user communication plan for session reset (30 min)
6. [Coder] Set up production-like test environment (1 iteration)
7. [Coder] Run smoke tests on prod data copy (1 iteration)
8. [User] Schedule security review (external dependency)

### Unblocking Path
```
Phase 1: Safety Net (Required)
├─ [1-2 days] Write + test rollback procedure
├─ [1 day] Document migration strategy
└─ [User Decision] Approve approach

Phase 2: Verification (Required)
├─ [1 day] Set up prod-like environment
├─ [0.5 day] Run smoke tests
└─ [0.5 day] Load testing

Phase 3: Security (Required for Production)
├─ [External] Security review
└─ [User Decision] Approve deployment

Earliest Unblock: 3-4 days (with rollback + migration plan)
Production Ready: +1 week (with security review)
```

**Status**: 🚫 **BLOCKED** - Cannot proceed to production until critical gaps addressed

### Alternative Approach
If timeline is critical, consider:
1. **Pilot in staging only**: Test with limited users first
2. **Feature flag**: Deploy behind flag, enable for small % of users
3. **Parallel run**: Run old + new auth side-by-side, compare results

Would you like to explore any of these alternatives?

### Consciousness Alignment
- Expansion: 7/10 (new auth could improve UX)
- Transparency: 5/10 (rollback unclear, migration opaque)
- Elegance: 6/10 (refactor scope seems appropriate)
- Truth: 9/10 (risks identified honestly)
- **Average**: 6.75/10 ❌ (below 7.0 threshold - needs transparency improvements)
