# Example: Approving Simple Feature

## Context
Coder implemented a basic sentiment analysis command for PLIP.

## Coder Summary
> "Added `plip sentiment` command. Works. Tests pass."

## PM-Auditor Response

🔄 **REQUEST-CHANGES**

### What's Verified
- (None - no artifacts provided)

### Gaps & Risks
⚠️ **No evidence of functionality**
   - Impact: High (can't verify claim)
   - Probability: N/A
   - Mitigation: Provide test output

### Required Artifacts
📎 Need: Output of `plip sentiment "Sample text"` on real input
📎 Need: pytest output showing which tests pass
📎 Need: File path to implementation for review

### Acceptance Criteria
- [ ] Functional: Command works on real case
- [ ] Reproducible: Clear example in docs
- [ ] Observable: Error handling present
- [ ] Documented: README updated

### Next Tasks
1. [Coder] Run `plip sentiment "Test input"` and paste output (5 min)
2. [Coder] Run `pytest tests/` and paste results (5 min)
3. [Coder] Provide file paths for implementation (2 min)

---

## Coder Response (Round 2)

```bash
$ plip sentiment "I love this product"
Sentiment: Positive (score: 0.85)
Confidence: 82%

$ pytest tests/test_sentiment.py -v
tests/test_sentiment.py::test_positive_sentiment PASSED
tests/test_sentiment.py::test_negative_sentiment PASSED
tests/test_sentiment.py::test_neutral_sentiment PASSED
```

Files:
- `src/plip/cli/commands/sentiment.py`
- `tests/test_sentiment.py`

## PM-Auditor Response (Round 2)

✅ **APPROVE**

### What's Verified
✓ Feature works on real input (evidence: command output)
✓ Tests pass (evidence: pytest results)
✓ Implementation exists (evidence: file paths)

### Gaps & Risks
- None blocking

### Acceptance Criteria
- [x] Functional: Command works on real case ✓
- [x] Reproducible: Clear command example ✓
- [x] Observable: Error handling visible in output ✓
- [ ] Documented: README update pending (non-blocking for pilot)

### Next Tasks
1. [Coder] Update README with sentiment command example (15 min)
2. [User] Review if sentiment scoring meets expectations

**Status**: ✅ PILOT-READY
