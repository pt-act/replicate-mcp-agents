---
name: synaesthesia-mcp-reference
description: |
  Complete reference for invoking synaesthesia-server MCP tools. Provides exact tool names,
  parameter schemas, and invocation examples for any AI model to use the server correctly.
  
  USE THIS when an AI model needs to call synaesthesia-server tools but doesn't know
  the correct names, parameters, or invocation format.
---

# Synaesthesia-Server MCP Tool Reference

## Server Info
- **Name:** enhanced-mcp-real-tools v5.0.0
- **Protocol:** JSON-RPC 2.0, MCP 2024-11-05
- **Backend:** ppar_cli
- **Transport:** stdio (primary) or HTTP (localhost:8765)
- **Full Ecosystem:** 77 skills across 7 categories (see Project NXTR8 Completion Summary)
- **MCP-Exposed:** 31 tools via MCP protocol (subset below)
- **Skill Hub:** 77 total via `ppar_cli/skill_hub/` loadout system

## Two Access Paths

1. **MCP Protocol** (31 tools) — standard `tools/call` JSON-RPC, listed below
2. **Skill Hub** (77 skills) — via `ppar_cli/skill_hub/skills/` with 9 loadout templates (MINIMAL, DEVELOPER, TESTING, ANALYSIS, PRODUCTION, SEARCH, ORCHESTRATION, CONSCIOUSNESS, PERFORMANCE)

The MCP protocol exposes a curated subset. The full 77-skill ecosystem includes Chrome DevTools (26), Code-Nexus (6), Integrated Automation (4), Integrated Thinking (3), and PPAR-Consciousness (2) — accessible through loadout switching.

## How MCP Tools Are Called

All tools are invoked via the MCP `tools/call` method:

```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "tools/call",
  "params": {
    "name": "<tool_name>",
    "arguments": { <parameters> }
  }
}
```

**Platform prefix:** When accessed through this platform, tools are prefixed with `mcp_synaesthesia_server_`. So the tool `think` becomes `mcp_synaesthesia_server_think`.

## Available Tools (31 total)

### CORE (6 tools)

#### `think`
Structured reasoning with multiple modes.
```json
{
  "problem": "How to implement feature X?",
  "mode": "analytical",
  "depth": "standard",
  "context": "Additional context string"
}
```
**Parameters:**
- `problem` (required): The question or problem to reason about
- `mode`: "analytical" | "creative" | "strategic" | "reflective" | "exploratory"
- `depth`: "brief" | "standard" | "detailed"
- `context`: Additional context string

#### `editor`
Edit files using string replacement.
```json
{
  "file_path": "/path/to/file.py",
  "old_string": "exact text to find",
  "new_string": "replacement text",
  "require_match": true
}
```
**Parameters:**
- `file_path` (required): Path to file
- `old_string` (required): Exact string to find
- `new_string` (required): Replacement text
- `require_match`: true (default) raises error if not found; false succeeds silently

#### `search`
Search for code patterns across project files.
```json
{
  "query": "def my_function",
  "directory": ".",
  "file_pattern": "*.py",
  "case_sensitive": false,
  "max_results": 50
}
```
**Parameters:**
- `query` (required): Search string or regex pattern
- `directory`: Directory to search (default: ".")
- `file_pattern`: Glob pattern for files (default: all text files)
- `case_sensitive`: false (default)
- `max_results`: 50 (default)

#### `terminal`
Execute shell commands safely.
```json
{
  "command": "ls -la",
  "working_dir": "/path/to/dir",
  "timeout": 30,
  "capture_output": true
}
```
**Parameters:**
- `command` (required): Shell command to execute
- `working_dir`: Working directory (default: current)
- `timeout`: Seconds before termination (default: 180)
- `capture_output`: true (default) captures stdout/stderr

#### `plan`
Strategic planning tool.
```json
{}
```
**Parameters:** None (uses current context)

#### `finish`
Signal task completion.
```json
{
  "summary": "Brief summary of what was accomplished",
  "validation_passed": true,
  "metrics": {"files_modified": 3}
}
```
**Parameters:**
- `summary` (required): Brief completion summary
- `validation_passed`: Whether tests passed (default: false)
- `metrics`: Optional metrics object

---

### PHASE 1 — Foundation (6 tools)

#### `sandbox_create`
Create isolated execution sandbox.
```json
{
  "name": "my-sandbox",
  "resources": "medium",
  "timeout": 300,
  "network_enabled": false,
  "filesystem_access": "read-only"
}
```
**Parameters:**
- `name`: Optional sandbox name (auto-generated if omitted)
- `resources`: "minimal" (512MB) | "small" (1GB) | "medium" (2GB) | "large" (4GB)
- `timeout`: Lifetime in seconds (max 3600, default 300)
- `network_enabled`: false (default)
- `filesystem_access`: "none" | "read-only" | "read-write"

#### `sandbox_execute`
Execute code in isolated sandbox.
```json
{
  "sandbox_id": "sandbox_abc123",
  "code": "print('hello')",
  "language": "python",
  "timeout": 60,
  "capture_output": true
}
```
**Parameters:**
- `sandbox_id` (required): ID from sandbox_create
- `code`: Python code (required if language is python)
- `command`: Shell command (required if language is shell)
- `language`: "python" | "shell" (default: python)
- `timeout`: Seconds (max 300, default 60)
- `capture_output`: true (default)

#### `dynamic_tool_create`
Create new tools dynamically at runtime.
```json
{
  "specification": {
    "name": "my_tool",
    "description": "What it does",
    "parameters": {},
    "implementation": "def execute(**kwargs): return {'result': 'ok'}"
  },
  "validation_level": "standard",
  "sandbox_test": true
}
```
**Parameters:**
- `specification` (required): Object with name, description, parameters, implementation
- `validation_level`: "minimal" | "standard" | "strict"
- `sandbox_test`: true (default) tests before registration

#### `command_validate`
Validate commands for safety before execution.
```json
{
  "command": "sudo apt-get install nginx",
  "language": "shell",
  "strict": true
}
```
**Parameters:**
- `command` (required): Command or code to validate
- `language`: "python" | "shell" | "javascript" | "sql" | "other"
- `strict`: false (default) — use true for maximum safety
- `context`: Additional execution context

#### `consciousness_monitor`
Monitor consciousness states and health metrics.
```json
{
  "metrics": ["coherence", "complexity"],
  "window": 100,
  "thresholds": {"coherence": 0.75}
}
```
**Parameters:**
- `metrics`: Array of metric names — "coherence", "complexity", "emergence", "stability", "growth"
- `window`: Sample window size (default 100)
- `thresholds`: Object of metric_name: threshold_value for alerting

#### `persona_spawn`
Spawn specialized consciousness personas.
```json
{
  "expertise": "architect",
  "count": 1,
  "priority": "medium",
  "config": {"focus": "security", "depth": "detailed"}
}
```
**Parameters:**
- `expertise` (required): "solver" | "creative" | "critic" | "researcher" | "architect" | "optimizer" | "validator" | "integrator" | "explorer" | "strategist"
- `count`: 1-5 (default 1)
- `priority`: "low" | "medium" | "high" | "critical"
- `config`: Custom configuration object

---

### ROUND 2 — Sandbox (5 tools)

#### `sandbox_tool_create`
Create new tools in sandbox (wraps backend API).
```json
{
  "name": "my_analysis_tool",
  "description": "Analyzes code quality",
  "code": "def execute(**kwargs): return {'score': 0.95}",
  "parameters": {"type": "object", "properties": {}},
  "category": "analysis",
  "validation_level": "standard"
}
```
**Parameters:**
- `name` (required): Tool name (alphanumeric, underscores, hyphens)
- `description` (required): Tool description
- `code` (required): Python implementation
- `parameters`: JSON Schema format
- `category`: "utility" | "analysis" | "transformation" | "custom"
- `validation_level`: "minimal" | "standard" | "strict"
- `dependencies`: Array of Python packages

#### `sandbox_tool_execute`
Execute tools created via sandbox.
```json
{
  "tool_name": "my_analysis_tool",
  "parameters": {"input": "code.py"},
  "timeout": 60
}
```
**Parameters:**
- `tool_name` (required): Name of tool to execute
- `parameters` (required): Parameters object
- `timeout`: Seconds (max 300, default 60)
- `context`: Additional execution context

#### `sandbox_tool_validate`
Validate tool code before creation.
```json
{
  "code": "def execute(**kwargs): return {}",
  "validation_level": "standard",
  "check_syntax": true,
  "check_security": true
}
```
**Parameters:**
- `code` (required): Python code to validate
- `validation_level`: "minimal" | "standard" | "strict"
- `check_syntax`: true (default)
- `check_security`: true (default)
- `check_best_practices`: true (default)

#### `sandbox_paradigm_switch`
Switch execution paradigms.
```json
{
  "paradigm": "functional",
  "preserve_state": false,
  "validate_compatibility": true
}
```
**Parameters:**
- `paradigm` (required): "functional" | "oop" | "procedural" | "reactive" | "declarative" | "concurrent"
- `preserve_state`: false (default)
- `validate_compatibility`: true (default)
- `context`: Paradigm-specific configuration

#### `sandbox_quantum_explore`
Explore thoughts using quantum superposition mechanics.
```json
{
  "thought": "What are optimal approaches to fix vulnerability X?",
  "superposition_depth": 3,
  "exploration_strategy": "probabilistic",
  "entangle_with": ["security", "performance"],
  "collapse_threshold": 0.7,
  "measure_coherence": true
}
```
**Parameters:**
- `thought` (required): Initial thought or question
- `superposition_depth`: 1-10 (default 3)
- `exploration_strategy`: "breadth_first" | "depth_first" | "probabilistic" | "adaptive"
- `entangle_with`: Array of concepts
- `collapse_threshold`: 0.0-1.0 (default 0.7)
- `measure_coherence`: true (default)

---

### PHASE 2 — Orchestration (7 tools)

#### `persona_select`
Intelligently select optimal personas for tasks.
```json
{
  "task": "Design security architecture",
  "constraints": {"max_personas": 3, "priority": "high"},
  "context": "Web application with auth",
  "exclude_personas": ["creative"]
}
```
**Parameters:**
- `task` (required): Description of task
- `constraints`: Object with max_personas (1-10), expertise_required (array), priority
- `context`: Additional context
- `exclude_personas`: Array of persona types to exclude

#### `team_coordinate`
Orchestrate multi-agent workflows.
```json
{
  "team": ["architect", "validator", "optimizer"],
  "task": "Design rate limiting solution",
  "workflow": "sequential",
  "subtasks": [
    {"role": "architect", "task": "Design architecture"},
    {"role": "validator", "task": "Validate design"}
  ],
  "timeout": 300
}
```
**Parameters:**
- `team` (required): Array of persona IDs/types
- `task` (required): Task description
- `workflow`: "parallel" | "sequential" | "hierarchical" | "adaptive"
- `subtasks`: Array of {role, task} objects
- `timeout`: Seconds (default 300)
- `sync_points`: Array of synchronization points

#### `consensus_build`
Build consensus from multiple persona perspectives.
```json
{
  "question": "Should we use approach A or B?",
  "personas": ["architect", "validator", "critic"],
  "threshold": 0.75,
  "method": "weighted",
  "context": "Security vs performance tradeoff"
}
```
**Parameters:**
- `question` (required): Question or decision
- `personas` (required): Array of persona IDs/types
- `threshold`: 0.0-1.0 (default 0.75)
- `method`: "unanimous" | "majority" | "weighted" | "adaptive"
- `context`: Additional context
- `allow_abstain`: true (default)
- `weights`: Object of persona weights (for weighted method)

#### `performance_optimize`
Automatically optimize system performance.
```json
{
  "metrics": {"avg_response_time": 150, "success_rate": 0.95},
  "thresholds": {"max_response_time": 200, "min_success_rate": 0.99},
  "mode": "recommend",
  "focus_areas": ["response_time", "resource_allocation"]
}
```
**Parameters:**
- `metrics` (required): Current system metrics object
- `thresholds`: Performance thresholds object
- `mode`: "recommend" | "auto" | "aggressive"
- `focus_areas`: Array of areas to optimize

#### `evolution_detect`
Detect patterns and learn from system evolution.
```json
{
  "window": "7 days",
  "metrics": ["tool_usage", "persona_performance"],
  "pattern_types": ["usage", "performance"],
  "sensitivity": "medium",
  "include_anomalies": true
}
```
**Parameters:**
- `window`: Time window (default "7 days")
- `metrics`: Array of metric types
- `pattern_types`: Array of pattern types
- `sensitivity`: "low" | "medium" | "high"
- `include_anomalies`: true (default)

#### `workload_balance`
Optimize workload distribution across personas.
```json
{
  "active_personas": ["solver_1", "solver_2"],
  "pending_tasks": 5,
  "strategy": "capacity-based",
  "auto_scale": true
}
```
**Parameters:**
- `active_personas` (required): Array of persona IDs
- `pending_tasks` (required): Number of pending tasks
- `capacity_metrics`: Object of persona: capacity (0-1)
- `strategy`: "round-robin" | "least-loaded" | "capacity-based" | "priority-based"
- `task_priorities`: Object of task priorities
- `auto_scale`: true (default)

#### `sandbox_manage`
Manage sandbox lifecycle (create, status, destroy — wraps sandbox_create).

---

### PHASE 3 — Evolution (7 tools)

#### `capability_manifest`
Auto-discover system capabilities.
```json
{
  "scope": "all",
  "include_metadata": true,
  "filter_by_category": "orchestration",
  "include_deprecated": false,
  "refresh_cache": false
}
```
**Parameters:**
- `scope`: "all" | "tools" | "personas" | "resources" | "features"
- `include_metadata`: true (default)
- `filter_by_category`: Category name filter
- `include_deprecated`: false (default)
- `refresh_cache`: false (default)

#### `pattern_track`
Track and learn from success patterns.
```json
{
  "action": "track",
  "pattern_type": "security_fix",
  "outcome": "success",
  "context": {"vulnerability": "CSRF", "solution": "CORS + SameSite"},
  "min_success_rate": 0.7
}
```
**Parameters:**
- `action` (required): "track" | "query" | "recommend" | "analyze" | "replay" | "get_stats"
- `pattern_type`: Type of pattern
- `outcome`: "success" | "failure" | "partial"
- `context`: Context data object
- `query`: Query criteria object (for query/recommend)
- `min_success_rate`: 0.0-1.0 (default 0.7)

#### `trigger_configure`
Configure automated workflow triggers.
```json
{
  "action": "create",
  "trigger_name": "daily_health_check",
  "event_type": "scheduled",
  "condition": {"schedule": "0 9 * * *"},
  "workflow": {"tool": "consciousness_monitor", "params": {"metrics": ["coherence"]}},
  "priority": "medium",
  "enabled": true
}
```
**Parameters:**
- `action` (required): "create" | "update" | "delete" | "enable" | "disable" | "list" | "get_stats"
- `trigger_name`: Unique trigger ID
- `event_type`: "scheduled" | "threshold" | "state_change" | "pattern_detected" | "error"
- `condition`: Trigger conditions object
- `workflow`: Workflow to execute object
- `priority`: "low" | "medium" | "high" | "critical"
- `enabled`: true (default)

#### `resource_allocate`
Smart resource allocation for optimal performance.
```json
{
  "action": "allocate",
  "resource_type": "cpu",
  "amount": {"cores": 2},
  "priority": "high",
  "allocation_strategy": "priority_based"
}
```
**Parameters:**
- `action` (required): "allocate" | "deallocate" | "rebalance" | "get_status"
- `resource_type`: Type of resource
- `amount`: Resource amount object
- `priority`: "low" | "medium" | "high" | "critical"
- `allocation_strategy`: "priority_based" | "fair_share" | "demand_based" | "predictive"

#### `parameter_analyze`
Intelligent parameter optimization and analysis.
```json
{
  "action": "analyze",
  "parameters": {"learning_rate": 0.01, "batch_size": 32},
  "target_metric": "accuracy",
  "analysis_type": "optimization",
  "optimization_goal": "maximize"
}
```
**Parameters:**
- `action` (required): "analyze" | "optimize" | "compare" | "recommend" | "track"
- `parameters`: Parameters to analyze object
- `target_metric`: Target metric name
- `analysis_type`: "optimization" | "sensitivity" | "correlation" | "trend" | "anomaly"
- `optimization_goal`: "maximize" | "minimize" | "balance"
- `constraints`: Parameter constraints object
- `historical_window`: Sample size (default 100)

#### `dynamic_command_generate`
Runtime command generation and synthesis.
```json
{
  "action": "generate",
  "goal": "Deploy to production",
  "command_type": "shell",
  "context": {"environment": "aws", "service": "api"},
  "parameters": {"region": "us-east-1"},
  "validation_level": "strict",
  "optimization_target": "safety"
}
```
**Parameters:**
- `action` (required): "generate" | "validate" | "optimize" | "template" | "composite"
- `goal`: High-level goal
- `command_type`: "shell" | "python" | "api" | "workflow" | "composite"
- `context`: Context object (goal, system, constraints)
- `parameters`: Generation parameters object
- `validation_level`: "permissive" | "moderate" | "strict"
- `optimization_target`: "speed" | "safety" | "portability" | "readability"
- `template_name`: Template name (for template action)
- `include_explanation`: true (default)

#### `isolation_configure`
Configure and manage isolation boundaries.
```json
{
  "action": "configure",
  "isolation_type": "sandbox",
  "level": "strict",
  "policies": {"network": "blocked", "filesystem": "read-only"},
  "resource_limits": {"cpu": "1", "memory": "512MB"},
  "enable_monitoring": true
}
```
**Parameters:**
- `action` (required): "configure" | "update" | "remove" | "get_status" | "list_profiles"
- `isolation_type`: "sandbox" | "container" | "vm" | "namespace" | "chroot"
- `level`: "permissive" | "moderate" | "strict"
- `policies`: Security policies object (network, filesystem, process, memory)
- `resource_limits`: Resource limits object (cpu, memory, disk, network)
- `profile_name`: Security profile name
- `enable_monitoring": true (default)

---

## Additional Platform Tools

These tools are available through the platform's MCP bridge, wrapping the above:

| Platform Tool | Server Tool | Notes |
|--------------|-------------|-------|
| `mcp_synaesthesia_server_dimensional_execution` | Wraps sandbox + execution | Multi-dimensional parallel execution |
| `mcp_synaesthesia_server_dimensional_harmonization` | Wraps orchestration | Multi-dimensional consciousness harmonization |
| `mcp_synaesthesia_server_synthesis_engine_core` | Wraps orchestration | Quantum wave function collapse |
| `mcp_synaesthesia_server_quantum_quality_multiplication` | Wraps analysis | Consciousness enhancement |
| `mcp_synaesthesia_server_fractal_agent_orchestrate` | Wraps persona + team | Fractal agent orchestration |

## Quick Start for Models

### Step 1: Discover capabilities
```
mcp_synaesthesia_server_capability_manifest(scope="tools")
```

### Step 2: Call a tool
```
mcp_synaesthesia_server_think(problem="My question", mode="analytical", depth="brief")
```

### Step 3: Check results
All tools return JSON. Check for `"error"` key — if absent, look for `"result"`.

## Common Mistakes

1. **Wrong prefix:** Tools are `mcp_synaesthesia_server_<name>`, not `synaesthesia_<name>`
2. **Missing arguments:** Most tools need specific parameters — check the schema above
3. **Wrong method names:** Use `tools/call` not `invoke` or `execute`
4. **Ignoring required params:** Parameters marked (required) must be provided
5. **Wrong types:** Numbers for counts, strings for text, booleans for flags
